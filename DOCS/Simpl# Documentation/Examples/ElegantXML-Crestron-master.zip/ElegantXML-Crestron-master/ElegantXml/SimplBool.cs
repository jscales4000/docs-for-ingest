﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;

namespace ElegantXml
{
    public static class SimplBool
    {
        public const ushort True = 1;
        public const ushort False = 0;
    }
}