﻿using System.Reflection;

[assembly: AssemblyTitle("ElegantXml")]
[assembly: AssemblyCompany("Elegant Video and Soundworks")]
[assembly: AssemblyProduct("ElegantXml")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyVersion("0.0.1.2")]