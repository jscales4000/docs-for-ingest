﻿using System;
using Crestron.SimplSharp;
using System.Net.Sockets;
/*
 * System.Net.Sockets is using .Net implementation of network sockets which runs natively on 4-series processors
 * if you want to run this on 3 series processors, you will have to use the sandbox version which is Crestron.SimplSharp.CrestronSockets
*/

namespace CrestronNetworkSockets
{
    class MyBasicTcpSocket
    {
        // Implementationed referenced from Microsoft
        // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.tcpclient?view=net-5.0

        // Command to play          = play\r
        // Command to stop          = stop \r
        // IP AddressOftheserver    = 192.168.86.204
        // Port of Server           = 49150 

        private string _command;     //Create a string variable private 

        //Create play and stop methods within the class as public 
        public void Play()           //Play Method 
        {
            _command = "play\r";     //Assign play command to string variable with a carriage return
            SendCommand(_command);   //Send command
        }

        public void Stop()           //Stop Method 
        {
            _command = "stop\r";      //Assing stop commmand to string variable with carriage return 
            SendCommand(_command);    //Send command
        }

        private void SendCommand(string commandToSend)
        {
            try
            {
                // Create a TcpClient.
                // Note, for this client to work you need to have a TcpServer
                // connected to the same address as specified by the server, port
                // combination.
                ushort port = 49150;
                string ipAddress = "192.168.86.204";
                TcpClient myTcpClient = new TcpClient(ipAddress, port);

                // Translate the passed message into ASCII and store it as a Byte array.
                Byte[] myByteData = System.Text.Encoding.ASCII.GetBytes(commandToSend);

                // Get a client stream for reading and writing.
                NetworkStream myStream = myTcpClient.GetStream();

                // Send the message to the connected TcpServer.
                myStream.Write(myByteData, 0, myByteData.Length);

                // String to store the response ASCII representation.
                String responseData = String.Empty;

                // Read the first batch of the TcpServer response bytes.
                Int32 myRxBytes = myStream.Read(myByteData, 0, myByteData.Length);
                responseData = System.Text.Encoding.ASCII.GetString(myByteData, 0, myRxBytes);
                CrestronConsole.PrintLine("Cd Server response: {0}", responseData);

                // Close everything.
                myStream.Close();
                myTcpClient.Close();
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in My Socket Implementation. Error: {0}", e.Message);
            }
        }
    }
}
