using System;
using System.Text;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharp.CrestronIO;

namespace ReadingFiles
{
    public class ControlSystem : CrestronControlSystem
    {
        // 4-Series File Reading

        // Common folder locations for file storage
        // - Application Directory (same app## folder as the running program)
        // - 'user' folder
        // - 'nvram' folder
        // - 'Removable Media'

        const string slFile = "Single.txt";
        const string mlFile = "Multi.txt";

        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                CrestronConsole.AddNewConsoleCommand(ReadFile, "ReadFile", "Output contents of file found.",
                  ConsoleAccessLevelEnum.AccessAdministrator);
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        void OpenAndRead(string incoming)
        {
            try
            {
                if (File.Exists(incoming))
                {
                    //string fileContents = File.ReadToEnd(incoming, Encoding.Default);

                    //StreamReader sr = new StreamReader(incoming);
                    //string fileContents = sr.ReadToEnd();

                    //CrestronConsole.PrintLine("File at {0} read. \rContents of file: {1}", incoming, fileContents);

                    string line;
                    using (var sr = new StreamReader(incoming))
                    {
                        while ((line = sr.ReadLine()) != null)
                        {
                            CrestronConsole.PrintLine("Output of sr.ReadLine = {0}", line);
                        }
                    }
                    

                    //sr.Close();
                }
                else
                    CrestronConsole.PrintLine("File {0} NOT found!", incoming);
            }
            catch (Exception e)
            {
                CrestronConsole.PrintLine("Error attempting to open and read {0}. Error = {1}", incoming, e.Message);
                throw;
            }
        }

        void ReadFile(string args)
        {
            string[] argsArray = args.Split(' ');   // Split on the 'space' character
            string filePath = "";

            switch (argsArray[0])
            {
                case slFile:
                case mlFile:
                    {
                        filePath = Path.Combine(Directory.GetApplicationDirectory(), args); // Current Application Folder
                        break;
                    }
                default:
                    {
                        CrestronConsole.PrintLine("Filename entered is not in switch/case.");
                        break;
                    }
            }

            if (filePath != "")
                OpenAndRead(filePath);
            else
                CrestronConsole.PrintLine("No file path entered!");
        }
    }
}