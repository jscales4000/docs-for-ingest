﻿using PepperDash.Core;

namespace NvxEpi.Features.Config;

public class NvxDirectorConfig
{
    public ControlPropertiesConfig Control { get; set; }
    public int NumberOfDomains { get; set; }
}