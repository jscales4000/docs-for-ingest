﻿using NvxEpi.Abstractions.Hardware;

namespace NvxEpi.Abstractions.Stream;

public interface IStreamWithHardware : IStream, INvxHardware
{
    
}