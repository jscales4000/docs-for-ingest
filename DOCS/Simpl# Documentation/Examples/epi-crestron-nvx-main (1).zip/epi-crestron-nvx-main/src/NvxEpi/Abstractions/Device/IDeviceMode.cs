﻿using PepperDash.Essentials.Core;

namespace NvxEpi.Abstractions.Device;

public interface IDeviceMode
{
    IntFeedback DeviceMode { get; }
}