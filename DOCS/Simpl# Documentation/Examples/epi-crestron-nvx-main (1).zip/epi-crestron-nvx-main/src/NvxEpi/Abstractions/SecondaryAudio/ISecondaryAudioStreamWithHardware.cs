﻿using NvxEpi.Abstractions.Hardware;

namespace NvxEpi.Abstractions.SecondaryAudio;

public interface ISecondaryAudioStreamWithHardware : ISecondaryAudioStream, INvxHardware
{
    
}