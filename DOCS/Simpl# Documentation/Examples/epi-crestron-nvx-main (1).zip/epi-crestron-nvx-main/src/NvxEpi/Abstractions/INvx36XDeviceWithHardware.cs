﻿using NvxEpi.Abstractions.Hardware;

namespace NvxEpi.Abstractions;

/*
public interface INvx36XDeviceWithHardware : INvxDeviceWithHardware, INvx36XHardware
{

}
 */