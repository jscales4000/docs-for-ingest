﻿namespace NvxEpi.Abstractions.Device;

public interface IDeviceId
{
    int DeviceId { get; }
}