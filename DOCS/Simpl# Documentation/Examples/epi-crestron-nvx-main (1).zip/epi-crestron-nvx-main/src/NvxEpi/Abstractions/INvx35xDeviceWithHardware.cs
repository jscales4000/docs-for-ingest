﻿using NvxEpi.Abstractions.Hardware;

namespace NvxEpi.Abstractions;

public interface INvx35XDeviceWithHardware : INvxDeviceWithHardware, INvx35XHardware
{
    
}