﻿using NvxEpi.Abstractions.Hardware;
using PepperDash.Essentials.Core;

namespace NvxEpi.Abstractions;

public interface INvxDeviceWithHardware : INvxDevice, INvxHardware
{
    
}