using NvxEpi.Abstractions.Hardware;

namespace NvxEpi.Abstractions;

public interface INvxD3XDeviceWithHardware : INvxDeviceWithHardware, INvxD3XHardware
{

}