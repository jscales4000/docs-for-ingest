using NvxEpi.Abstractions.Hardware;

namespace NvxEpi.Abstractions;

public interface INvxE3XDeviceWithHardware : INvxDeviceWithHardware, INvxE3XHardware
{

}