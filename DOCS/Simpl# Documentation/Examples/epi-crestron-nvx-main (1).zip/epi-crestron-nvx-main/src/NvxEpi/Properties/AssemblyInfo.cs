﻿using System.Reflection;

[assembly: AssemblyTitle("NvxEpi")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("NvxEpi")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]
[assembly: AssemblyInformationalVersion("0.0.0-buildType-build#")]
[assembly: Crestron.SimplSharp.Reflection.AssemblyInformationalVersion("0.0.0-buildType-build#")]
