# SimplSharpPrimer
A SIMPL# Pro Primer

This repository provides access to the code and touchpanel layouts that we'll generate by following the primer at https://kielthecoder.com/tag/primer/

More parts will be added as the series develops on my blog.
