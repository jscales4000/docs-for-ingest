﻿using System.Reflection;

[assembly: AssemblyTitle("Part2")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Part2")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

