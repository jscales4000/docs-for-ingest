﻿using System.Reflection;

[assembly: AssemblyTitle("Part5")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Part5")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

