﻿using System.Reflection;

[assembly: AssemblyTitle("Part3")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Part3")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

