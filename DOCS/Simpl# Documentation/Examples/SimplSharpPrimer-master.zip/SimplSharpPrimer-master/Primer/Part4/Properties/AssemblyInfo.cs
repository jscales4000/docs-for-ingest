﻿using System.Reflection;

[assembly: AssemblyTitle("Part4")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Part4")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

