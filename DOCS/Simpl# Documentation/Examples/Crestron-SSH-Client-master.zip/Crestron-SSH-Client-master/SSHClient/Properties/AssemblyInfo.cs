﻿using System.Reflection;

[assembly: AssemblyTitle("SSHClient")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SSHClient")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyVersion("1.0.0.*")]

