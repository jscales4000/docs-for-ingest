# Crestron-SSH-Client
SIMPL+ / SIMPL# SSH Client module

Feel free to use this module in your systems. Open Test.smw to see example of use in standard system.

If you find this module useful, please star my repo and/or send me a message on Twitter: @frasermclean81
