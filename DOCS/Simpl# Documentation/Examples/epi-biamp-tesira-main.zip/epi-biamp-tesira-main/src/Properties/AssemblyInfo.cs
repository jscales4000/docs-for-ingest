﻿using System.Reflection;

[assembly: AssemblyTitle("Tesira_DSP_EPI")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Tesira_DSP_EPI")]
[assembly: AssemblyCopyright("Copyright © 2020")]
[assembly: AssemblyVersion("0.0.0.*")]
[assembly: AssemblyInformationalVersion("0.0.0.*")]
[assembly: Crestron.SimplSharp.Reflection.AssemblyInformationalVersion("0.0.0.*")]

