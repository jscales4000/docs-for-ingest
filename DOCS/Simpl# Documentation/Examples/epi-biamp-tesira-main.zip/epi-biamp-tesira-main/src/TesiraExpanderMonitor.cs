﻿using PepperDash.Core;
using PepperDash.Essentials.Core;

namespace Tesira_DSP_EPI
{
    public class TesiraExpanderMonitor : StatusMonitorBase
    {



        public TesiraExpanderMonitor(IKeyed parent, long warningTime, long errorTime)
            : base(parent, warningTime, errorTime)
        {

        }

        public override void Start()
        {
        }

        public override void Stop()
        {
        }

    }
}