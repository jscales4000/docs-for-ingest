var searchData=
[
  ['offhook_173',['OffHook',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_dialer.html#ab3efabf45881c99b9c36f6f62293d6df',1,'Tesira_DSP_EPI::TesiraDspDialer']]],
  ['onhook_174',['OnHook',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_dialer.html#a1eaaa8fb762f65ade81f897e79b1a35f',1,'Tesira_DSP_EPI::TesiraDspDialer']]]
];
