var searchData=
[
  ['offhookfeedback_217',['OffHookFeedback',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_dialer.html#adabe1aa5910ef8f0aaab6ed9e7f41cc3',1,'Tesira_DSP_EPI::TesiraDspDialer']]]
];
