var searchData=
[
  ['rejectcall_79',['RejectCall',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_dialer.html#a26dc6d4284538e1f5c105eb4fbe1624a',1,'Tesira_DSP_EPI::TesiraDspDialer']]],
  ['roomgroupfeedback_80',['RoomGroupFeedback',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_room_combiner.html#a794a481e0173b23f4a4faebcd4eb583a',1,'Tesira_DSP_EPI::TesiraDspRoomCombiner']]],
  ['routingport_81',['RoutingPort',['../class_tesira___d_s_p___e_p_i_1_1_routing_port.html',1,'Tesira_DSP_EPI']]],
  ['runpreset_82',['RunPreset',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp.html#af2d8b033084123de4727e8a54d902a73',1,'Tesira_DSP_EPI::TesiraDsp']]]
];
