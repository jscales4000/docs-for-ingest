var searchData=
[
  ['offhookstatus_252',['OffHookStatus',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_dialer.html#a16a648f5a1f1481a9e8b1fba17ce8632',1,'Tesira_DSP_EPI::TesiraDspDialer']]],
  ['outputports_253',['OutputPorts',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_switcher.html#afed3f923cb38e12fc3b5d886dd282ca6',1,'Tesira_DSP_EPI::TesiraDspSwitcher']]]
];
