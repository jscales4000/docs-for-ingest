var searchData=
[
  ['incomingcallfeedback_213',['IncomingCallFeedback',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp_dialer.html#afac0f7189565753e56ec30c746b1cce3',1,'Tesira_DSP_EPI::TesiraDspDialer']]],
  ['issubscribed_214',['IsSubscribed',['../class_tesira___d_s_p___e_p_i_1_1_tesira_dsp.html#a3101bd717dff57f9012aabc33381bb81',1,'Tesira_DSP_EPI::TesiraDsp']]]
];
