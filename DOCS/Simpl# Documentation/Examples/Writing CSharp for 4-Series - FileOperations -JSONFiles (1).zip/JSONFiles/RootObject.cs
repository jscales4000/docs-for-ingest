﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSONFiles
{
    public class Source
    {
        public string SourceName { get; set; }
    }

    public class Room
    {
        public string RoomName { get; set; }
        public List<Source> Sources { get; set; }
    }

    public class RootObject
    {
        public List<Room> Rooms { get; set; }
    }    
}
