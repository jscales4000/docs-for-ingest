using System;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharp.CrestronIO;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace JSONFiles
{
    public class ControlSystem : CrestronControlSystem
    {
        // 4-Series File Reading/Writing

        // Common folder locations for file storage
        // - Application Directory (same app## folder as the running program)
        // - 'user' folder
        // - 'nvram' folder
        // - 'Removable Media'

        RootObject ro = new RootObject();

        string JSONDataAsAString = "";
        string filePath = "/rm/myJSONfile.json";

        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                CrestronConsole.AddNewConsoleCommand(SeedData, "SeedData", "Seed data to RootObject.",
                  ConsoleAccessLevelEnum.AccessAdministrator);
                CrestronConsole.AddNewConsoleCommand(WriteJSON, "WriteJSON", "Write data to JSON file.",
                  ConsoleAccessLevelEnum.AccessAdministrator);
                CrestronConsole.AddNewConsoleCommand(ReadJSON, "ReadJSON", "Read data from JSON file.",
                  ConsoleAccessLevelEnum.AccessAdministrator);
                CrestronConsole.AddNewConsoleCommand(AccessData, "AccessData", "List sources in a room.",
                  ConsoleAccessLevelEnum.AccessAdministrator);
                CrestronConsole.AddNewConsoleCommand(AddRoom, "AddRoom", "Add room to RootObject.",
                  ConsoleAccessLevelEnum.AccessAdministrator);
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }

            void AddRoom(string args)
            {
                string[] arrayArgs = args.Split(' ');   // Split on the 'space' character
                string roomTarget = arrayArgs[0];
                string[] newSources = new string[arrayArgs.Length - 1];

                for (int i = 1; i < arrayArgs.Length; i++)
                    newSources[i - 1] = arrayArgs[i];

                ro.Rooms.Add(new Room()
                {
                    RoomName = roomTarget,
                    Sources = new List<Source>()
                });

                int roomIndex = ro.Rooms.FindIndex(p => p.RoomName == roomTarget);

                foreach (var source in newSources)
                {
                    ro.Rooms[roomIndex].Sources.Add(new Source() { SourceName = source });
                }

                CrestronConsole.PrintLine("AddRoom completed.");
            }

            void SeedData(string args)
            {
                ro.Rooms = new List<Room>();
                ro.Rooms.Add(new Room()
                {
                    RoomName = "Bedroom",
                    Sources = new List<Source>()
                    {
                        new Source { SourceName = "MediaStreamer" },
                        new Source { SourceName = "SatelliteTuner" },
                        new Source { SourceName = "GameConsole" }
                    }
                });
                ro.Rooms.Add(new Room()
                {
                    RoomName = "Livingroom",
                    Sources = new List<Source>()
                    {
                        new Source { SourceName = "SatelliteTuner" },
                    }
                });
                ro.Rooms.Add(new Room()
                {
                    RoomName = "Basement",
                    Sources = new List<Source>()
                    {
                        new Source { SourceName = "MediaStreamer" },
                        new Source { SourceName = "SatelliteTuner" },
                        new Source { SourceName = "GameConsole" },
                        new Source { SourceName = "BluRayPlayer" }
                    }
                });
            }

            void WriteJSON(string args)
            {
                try
                {
                    JSONDataAsAString = JsonConvert.SerializeObject(ro);

                    using (FileStream fs = File.Create(filePath))
                        fs.Write(JSONDataAsAString, System.Text.Encoding.Default);

                    CrestronConsole.PrintLine("JSON file written.");
                }
                catch (Exception e)
                {
                    CrestronConsole.PrintLine("Error in Writing JSON data. Error = {0}", e.Message);
                }
            }


            void AccessData(string args)
            {
                string[] arrayArgs = args.Split(' ');   // Split on the 'space' character
                string roomTarget = arrayArgs[0];
                int roomIndex = -1;

                if (ro.Rooms.Exists(p => p.RoomName == roomTarget))
                    roomIndex = ro.Rooms.FindIndex(p => p.RoomName == roomTarget);

                if (roomIndex >= 0)
                {
                    foreach (var source in ro.Rooms[roomIndex].Sources)
                    {
                        CrestronConsole.PrintLine("{0} has {1} as a source.", ro.Rooms[roomIndex].RoomName, source.SourceName);
                    }
                }
                else
                    CrestronConsole.PrintLine("Room \"{0}\" NOT found!", roomTarget);
            }

            void ReadJSON(string args)
            {
                try
                {
                    using (StreamReader sr = new StreamReader(filePath, System.Text.Encoding.Default))
                        JSONDataAsAString = sr.ReadToEnd();

                    CrestronConsole.PrintLine("JSON data read = {0}", JSONDataAsAString);

                    ro = JsonConvert.DeserializeObject<RootObject>(JSONDataAsAString);
                }
                catch (Exception e)
                {
                    CrestronConsole.PrintLine("Error in Reading JSON data. Error = {0}", e.Message);
                }
            }
        }
    }
}