﻿using System.Reflection;

[assembly: AssemblyTitle("SmartThings")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SmartThings")]
[assembly: AssemblyCopyright("Copyright ©  2015")]
[assembly: AssemblyVersion("1.0.0.*")]

