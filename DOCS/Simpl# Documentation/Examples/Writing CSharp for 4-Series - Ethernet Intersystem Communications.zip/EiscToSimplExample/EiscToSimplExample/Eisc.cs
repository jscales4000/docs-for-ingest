﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crestron.SimplSharp;
using Crestron.SimplSharpPro;
using Crestron.SimplSharpPro.EthernetCommunication; // For EISC
namespace EiscToSimplExample
{
    class Eisc
    {

        private uint _ID;
        private string _ipAddress;

        EthernetIntersystemCommunications myEisc; // Container for the EISC

        public bool Online 
        { 
            get { return myEisc.IsOnline;  }
        }

        // Setup our event handler with our custom event arguments
        public event EventHandler<EiscEventArgs> myEvent;


        public Eisc(uint ID, string IPaddress, ControlSystem cs) // Default constructor
        {
            // NOTE:    Some will recommend checking for Ethernet but no 3 or 4 series processor exists that 
            //          does not have Ethernet

            myEisc = new EthernetIntersystemCommunications(ID, IPaddress, cs);
            myEisc.Register();  //Register with the control system this IPID and Eisc

            //Subscribe to the events
            myEisc.OnlineStatusChange += MyEisc_OnlineStatusChange;
            myEisc.SigChange += MyEisc_SigChange;

            _ID = ID; // Store the ID we were set to
            _ipAddress = IPaddress; // store the ipaddress we used

            CrestronConsole.PrintLine("EISC created");
        }

        //Digitals
        public void SetDigital(uint Join,bool Value)
        {
            myEisc.BooleanInput[Join].BoolValue = Value;
        }
        public bool GetDigtal(uint Join)
        {
            return myEisc.BooleanOutput[Join].BoolValue;
        }
        //Analogs
        public void SetAnalog(uint Join, ushort Value)
        {
            myEisc.UShortInput[Join].UShortValue = Value;
        }
        public uint GetAnalog(uint Join)
        {
            return myEisc.UShortOutput[Join].UShortValue;
        }
        //Serials
        public void SetSerial(uint Join, string Value)
        {
            myEisc.StringInput[Join].StringValue = Value;
        }
        public string GetSerial(uint Join)
        {
            return myEisc.StringOutput[Join].StringValue;
        }

        private void MyEisc_SigChange(Crestron.SimplSharpPro.DeviceSupport.BasicTriList currentDevice, SigEventArgs args)
        {
            OnRaiseEvent(new EiscEventArgs("Signal", args));  //  Call our event handler

        }

        private void MyEisc_OnlineStatusChange(GenericBase currentDevice, OnlineOfflineEventArgs args)
        {
            OnRaiseEvent(new EiscEventArgs("OnlineOffline"));  //  Call our event handler
        }

        // Event Handler
        protected virtual void OnRaiseEvent(EiscEventArgs e)
        {
            EventHandler<EiscEventArgs> raiseEvent = myEvent; // make a copy


            if (raiseEvent != null) // do we have subscribers?
            {
                e.Online = Online; // Set any event variables
                e.ID = _ID;
                e.IpAddress = _ipAddress;

                raiseEvent(this, e);  // Fire the event
            }

        }
    }

    class EiscEventArgs
    {
        
        public EiscEventArgs(string message)
        {
            Message = message;
        }
        // Added an overload for when joins need to be sent
        public EiscEventArgs(string message, SigEventArgs args )
        {
            Message = message;
            Args = args;
        }
        public string Message { get; set; }
        public SigEventArgs Args { get; set; }
        public bool Online { get; set; }
        public uint ID { get; set; }
        public string IpAddress { get; set; }
    }
}
