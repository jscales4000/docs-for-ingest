﻿using System.Reflection;

[assembly: AssemblyTitle("EssentialsPluginTemplateEpi")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("EssentialsPluginTemplateEpi")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion("1.0.0.*")]

