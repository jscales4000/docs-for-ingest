﻿using System.Reflection;

[assembly: AssemblyTitle("EcloudUtils")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("EcloudUtils")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyVersion("1.0.0.*")]

