﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyInterface
{
    /// <summary>
    /// This is the interface template we are going to use for our reflection
    /// This interface MUST be used in your program and in all libraries you intend to reflect into your
    /// program that are going to be based on this interface.  Using an Interface will significantly simplify
    /// your use of reflection.  Without an interface you must dig into the dll and discover everything.
    /// 
    /// This interface MUST be referenced in your program and your libraries that will be based on it
    /// </summary>
    public interface IpluginInterface
    {
        string Address { set; }
        ushort Port { set; }
        bool Connected { get; }
        bool Power { get; }

        bool Debug { set; }

        string Tx { set; }
        string Rx { get; }

        event EventHandler<DeviceEventArgs> DeviceEvent;

        void Connect();
        void Disconnect();

        void Command(string s);
    }
    public class DeviceEventArgs : EventArgs
    {
        public DeviceEventArgs(string message)
        {
            Message = message;
        }
        public string Message { get; set; }
        public string Rx { get; set; }
        public bool Connected { get; set; }

        public bool Power { get; set; }
    }
}
