using System;
using System.Reflection;                                // we need this for Reflection
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharpPro.UI;         	            // For Touch Panel

using MyInterface;                                      // Need this for library we are reflecting in

namespace CrestronCSharpReflection
{
    public class ControlSystem : CrestronControlSystem
    {
        IpluginInterface myDevice;  // Container for our reflected Assembly
        XpanelForSmartGraphics myXpanel;

        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;


            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }


        public override void InitializeSystem()
        {
            try
            {

                

                var myDll = Assembly.LoadFrom(@"\NVRAM\ReflectionLibrary1.dll"); // Load our DLL from NVRAM where we copied it
                CrestronConsole.PrintLine("Program Loaded Library");
                foreach (var type in myDll.GetTypes())  //List what we have available inside the DLL
                {
                    CrestronConsole.PrintLine("Found {0} inside the DLL", type.FullName);
                }
                Type[] myType = myDll.GetTypes(); //Above we listed the contents, here we are loading them into an array

                // because our dll is written by us we can make assumptions.  the Class that matches our Interface is the 
                // first one to be found so that is the one we are going to use. If not then more code would be required to ensure 
                // we use the proper class.

                // We now need to create an instance of the class we want inside that dll and leverage the interface we have in common with it
                // using the reflection activator and creating an instance of the object we loaded into the array,  we want to only load what
                // is at index 0 as that is the first class.   WE should validate that it is a class.

                if (myType[0].IsClass == true)  // Is this a Class?
                {
                    CrestronConsole.PrintLine("Library is valid, found the class at 0");
                    myDevice = (IpluginInterface)Activator.CreateInstance(myType[0]);  // Instantiate the class

                    myDevice.Address = "127.0.0.1"; // We are running an emulator on another slot
                    myDevice.Port = 5151;           // Port Number for the device I want to talk to
                    myDevice.DeviceEvent += MyDevice_DeviceEvent; // Subscribe to the event handler
                }
                else
                {
                    CrestronConsole.PrintLine("First type in the assembly was not a class.");
                }

                //  Lets add a simple Touchscreen so we can control the projector
                myXpanel = new XpanelForSmartGraphics(0x14, this);
                myXpanel.Register();
                myXpanel.SigChange += MyXpanel_SigChange;


            }

            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        private void MyDevice_DeviceEvent(object sender, DeviceEventArgs e)
        {
            CrestronConsole.PrintLine("Programs Library Event Handler Called");
            switch (e.Message)
            {
                case "STATUS":
                    {
                        // Set touch panel feedback based on connect status from the reflected library
                        if(e.Connected)
                        {
                            myXpanel.BooleanInput[2].BoolValue = false;
                            myXpanel.BooleanInput[1].BoolValue = true;
                            myXpanel.StringInput[1].StringValue = "CONNECTED";
                        } 
                        else
                        {
                            myXpanel.BooleanInput[1].BoolValue = false;
                            myXpanel.BooleanInput[2].BoolValue = true;
                            myXpanel.StringInput[1].StringValue = "DISCONNECTED";
                        }
                        break;
                    }
                   
                case "RX":
                    myXpanel.StringInput[1].StringValue = e.Rx; // Send the text we got from the module to the touch panel
                    break;
                case "FAIL":
                    myXpanel.StringInput[1].StringValue = "FAILED TO CONNECT";
                    break;
                default:
                    break;

            }
        }

        private void MyXpanel_SigChange(BasicTriList currentDevice, SigEventArgs args)
        {
            if (args.Sig.BoolValue == true)
            {
                switch (args.Sig.Number)
                {
                    case 1:
                        {
                            myDevice.Connect();
                            break;
                        }
                    case 2:
                        {
                            myDevice.Disconnect();
                            break;
                        }
                    case 3:
                        {
                            myDevice.Command("ON");
                            break;
                        }
                    case 4:
                        {
                            myDevice.Command("OFF");
                            break;
                        }
                    default:
                        break;
                }
            }
        }
    }
}