﻿using System;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharp.CrestronSockets;              // For Sockets
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading

using MyInterface;  // MUST have our using statement in place so we can use it.

namespace ReflectionLibrary1
{
    public class MyProjector : IpluginInterface
    {
        // Note: Some programmers prefer _address to address here.  BOTH are valid. 
        // typically _ is added by VB programmers as VB is case insensitive.
        private string address = "";
        private ushort port = 0;
        private bool debug = false;
        private string lastRX = "";
        private bool power = false;
        public string Address { set { address = value; } }
        public ushort Port { set { port = value; } }
        public bool Connected
        {
            get
            {
                if (myClient.ClientStatus == SocketStatus.SOCKET_STATUS_CONNECTED)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public bool Power { get { return power; } }

        public bool Debug { set { debug = value; } }

        public string Tx { set { txQueue.Enqueue(value); } }
        public string Rx { get { return lastRX; } }

        public event EventHandler<DeviceEventArgs> DeviceEvent;

        private Thread myThread;
        private CrestronQueue txQueue;
        private TCPClient myClient;
        private bool RunThread = false;


        // Default Constructor
        public MyProjector()
        {
            txQueue = new CrestronQueue();
            CrestronConsole.PrintLine("Library Instance Created");

        }
        //De-constructor
        ~MyProjector()
        {
            RunThread = false;  // stop the thread on deconstruction
            CrestronConsole.PrintLine("Library Instance Destroyed");
        }

        public void Command(string s)
        { 
            switch(s)
            {
                case "ON":
                    txQueue.Enqueue("\x02PON\x03");  // Send API command for ON
                    break;
                case "OFF":
                    txQueue.Enqueue("\x02POF\x03");     // Send API command for OFF
                    break;
                default:
                    break;
            }
        }

        public void Connect()
        {
            CrestronConsole.PrintLine("Library Connect Called");
            myClient = new TCPClient(address, port, 1024);  // Create the Client
            myClient.SocketStatusChange += MyClient_SocketStatusChange;
            myThread = new Thread(ThreadCode, null);
            RunThread = true;
            txQueue.Clear();    // Empty the queue
            myThread.Start();   // Start our thread
        }

        /// <summary>
        /// Call this method to disconnect from the Server or device.
        /// All data will be cleared from the TX and RX
        /// </summary>
        public void Disconnect()
        {
            CrestronConsole.PrintLine("Library Disconnect Called");
            RunThread = false;
            myClient.DisconnectFromServer();
            txQueue.Clear();    // Empty the queue
            lastRX = "";
            myClient.Dispose();
        }

        private void MyClient_SocketStatusChange(TCPClient myTCPClient, SocketStatus clientSocketStatus)
        {
            CrestronConsole.PrintLine("Library Socket Status changed");
            OnRaiseEvent(new DeviceEventArgs("STATUS")); // Call the Event Handler
        }



        // The code in this method is what will be run as our  worker thread watching for incoming data and when a message
        // is added to the Queue it is sent out to the TCP connection.
        // It also starts the connection in the thread
        private object ThreadCode(object o)
        {
            if (myClient.ConnectToServer() == 0) // Connect and look for a success
            {
                //TCP Client loop for TX and RX
                while (RunThread)
                {
                    if (myClient.ClientStatus == SocketStatus.SOCKET_STATUS_CONNECTED) // Are we connected?
                    {
                        // Process outgoing data
                        if (!txQueue.IsEmpty)  // Do we have something in the Queue to send
                        {
                            string temp = txQueue.Dequeue().ToString();                 // Get our TX data out of the Queue

                            byte[] payload = System.Text.Encoding.ASCII.GetBytes(temp); // Convert the string to Bytes ASCII
                            myClient.SendData(payload, payload.Length);                  // Send it out to the TCP connection
                        }

                        // Wait for Data incoming
                        if (myClient.DataAvailable)  // Do we have data to read?
                        {
                            myClient.ReceiveData(); // Extract the data into out IncomingDataBuffer
                            string Buffer = System.Text.Encoding.ASCII.GetString(myClient.IncomingDataBuffer); // we get bytes, make it a string
                            lastRX = Buffer.TrimEnd('\x00'); // make a copy in case the user wants to look at the last packet received, get rid of any trailing \x00's
                            CrestronConsole.PrintLine("Library Socket Got a packet");
                            // Parse any responses and set values
                            if (lastRX.Contains("PON"))
                            {
                                power = true;
                            }
                            else if(lastRX.Contains("POF"))
                            {
                                power = false;
                            }

                            OnRaiseEvent(new DeviceEventArgs("RX")); // Call the Event Handler
                        }
                    }
                    else
                    {
                        RunThread = false;  // we are not connected, kill the thread
                    }
                }
            }
            else
            {
                myClient.DisconnectFromServer(); // we had an error connecting. be safe and kill the connection
                RunThread = false;
                OnRaiseEvent(new DeviceEventArgs("FAIL")); // Call the Event Handler
            }
            return null;
        }

        protected virtual void OnRaiseEvent(DeviceEventArgs e)
        {
            EventHandler<DeviceEventArgs> raiseEvent = DeviceEvent;  // Make a copy of the event

            if (raiseEvent != null) // Verify we have subscribers
            {
                // Set all our event variables
                e.Connected = Connected;
                e.Rx = lastRX;

                raiseEvent(this, e); // trigger the event
            }
        }
    
    }
}
