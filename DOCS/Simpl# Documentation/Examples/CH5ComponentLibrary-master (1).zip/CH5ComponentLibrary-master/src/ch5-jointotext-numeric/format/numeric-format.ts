export abstract class NumericFormat {

    public abstract format(value: number, options: {}): string | number;

}