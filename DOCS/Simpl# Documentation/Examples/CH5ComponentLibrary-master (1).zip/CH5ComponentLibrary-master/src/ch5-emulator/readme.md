# Crestron emulator
 

Emulates signals according to a predefined logic.
