// Copyleft (C) 2021 to the present, Crestron Electronics, Inc.
// All rights reserved.
// No part of this software may be reproduced in any form, machine
// or natural, without the express written consent of Crestron Electronics.
// Use of this source code is subject to the terms of the Crestron Software License Agreement
// under which you licensed this source code.

import { ICh5DpadButtonBaseAttributes } from "./i-ch5-dpad-button-base-attributes";

/**
 * @name Ch5 Dpad Button
 * @isattribute false
 * @tagName ch5-dpad-button
 * @role container
 * @description This is a child component of ch5-dpad
 * @componentVersion 1.0.0
 * @documentation
 * [
 * "`ch5-dpad-button` element",
 * "***",
 * "DPad Button <ch5-dpad-button key=`value`> component can be added under a <ch5-dpad> tag ",
 * "for customization related to icon as a url or an icon class. ",
 * "Note: This tag can never be independently used and always needs the container <ch5-dpad> to render."
 * ]
 * @snippets
 * [
 *  {
 *    "prefix": "ch5-dpad-button key=\"down\":blank",
 *     "description": "Crestron Dpad Button Blank",
 *     "body": [
 *       "<ch5-dpad-button key=\"${1|center,up,down,left,right|}\">",
 *       "</ch5-dpad-button>$0"
 *     ]
 *  },
 *  {
 *    "prefix": "ch5-dpad-button:iconurl",
 *     "description": "Crestron Dpad Icon Url",
 *     "body": [
 *       "<ch5-dpad-button key=\"${1|center,up,down,left,right|}\" iconurl=\"btn_${2:Icon Url}\">",
 *       "</ch5-dpad-button>$0"
 *     ]
 *  },
 *  {
 *    "prefix": "ch5-dpad-button:iconclass",
 *     "description": "Crestron Dpad Icon Class",
 *     "body": [
 *       "<ch5-dpad-button key=\"${1|center,up,down,left,right|}\" iconclass=\"btn_${2:Icon Class}\">",
 *       "</ch5-dpad-button>$0"
 *     ]
 *  },
 *  {
 *    "prefix": "ch5-dpad-button:all-attributes",
 *     "description": "Crestron Dpad All Attributes",
 *     "body": [
 *       "<ch5-dpad-button key=\"${1|center,up,down,left,right|}\"",
 *       "\ticonurl=\"btn_${2:IconUrl}\"",
 *       "\tpressed=\"${3:false}\"",
 *       "\tlabel=\"${4:Label}\"",
 *       "\ticonclass=\"${5:iconClass}\">",
 *       "</ch5-dpad-button>$0"
 *     ]
 *  }
 * ]
 * 
 */
export interface ICh5DpadButtonAttributes extends ICh5DpadButtonBaseAttributes {
}
