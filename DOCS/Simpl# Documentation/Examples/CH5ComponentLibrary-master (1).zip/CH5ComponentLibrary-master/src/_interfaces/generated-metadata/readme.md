<p align="center">
  <img src="https://kenticoprod.azureedge.net/kenticoblob/crestron/media/crestron/generalsiteimages/crestron-logo.png">
</p>
 
# Extension schema generation folder
This folder contains the generated schema and other json output files from the library and theme code.
