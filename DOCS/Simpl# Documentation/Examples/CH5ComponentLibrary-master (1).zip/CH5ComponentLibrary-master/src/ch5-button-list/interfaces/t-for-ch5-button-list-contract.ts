export interface ICh5ButtonListContractObj {
  index: number;
  clickHoldTime: number;
  contractName: string;
  parentComponent: string;
};