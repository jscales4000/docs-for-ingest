export * from './i-ch5-jointotext-string-attributes';
export * from './i-ch5-jointotext-string-documentation';