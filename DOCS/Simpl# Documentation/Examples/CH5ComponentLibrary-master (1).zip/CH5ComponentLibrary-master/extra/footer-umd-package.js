/* extra/footer-umd-package.js */

// generated code by WebPack only for umd distributions
window['bridgeReceiveIntegerFromNative'] = CrComLib.bridgeReceiveIntegerFromNative;
window['bridgeReceiveBooleanFromNative'] = CrComLib.bridgeReceiveBooleanFromNative;
window['bridgeReceiveStringFromNative'] = CrComLib.bridgeReceiveStringFromNative;
window['bridgeReceiveObjectFromNative'] = CrComLib.bridgeReceiveObjectFromNative;