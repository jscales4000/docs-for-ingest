﻿

namespace PepperDash.Core.JsonToSimpl
{
    /// <summary>
    /// 
    /// </summary>
	public class JsonToSimplFixedPathObject : JsonToSimplChildObjectBase
	{
        /// <summary>
        /// Constructor
        /// </summary>
		public JsonToSimplFixedPathObject()
		{
			this.LinkedToObject = true;
		}
	}
}