﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;

namespace PepperDash.Core
{
    /// <summary>
    /// Not in use
    /// </summary>
	public static class NetworkComm
	{
        /// <summary>
        /// Not in use
        /// </summary>
		static NetworkComm()
		{
		}
	}

}