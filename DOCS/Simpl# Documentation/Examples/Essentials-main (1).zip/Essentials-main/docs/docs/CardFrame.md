        {
                "key": "cardCage1",
                "uid": 1,
                "name": "Internal Card Cage",
                "type": "internalcardcage",
                "group": "cardCage",
                "properties": {
                  "cards": {
                    "1": "c3com3",
                    "2": "c3com3",
                    "3": ""
                  }
                }
            },