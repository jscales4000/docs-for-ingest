# Essentials Configurable System Lifecycle

The diagram below describes how Essentials gets a program up and running.

(The various activation phases are covered in more detail on the [next page](~/docs/Arch-activate.md))

![Lifecycle](~/docs/images/lifecycle.png)

Next: [Activation phases](~/docs/Arch-activate.md)
