﻿
namespace PepperDash.Essentials.Room.Config
{
    /// <summary>
    /// Represents a EssentialsDualDisplayRoomPropertiesConfig
    /// </summary>
    public class EssentialsDualDisplayRoomPropertiesConfig : EssentialsNDisplayRoomPropertiesConfig
    {

    }
}