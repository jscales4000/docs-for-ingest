﻿
namespace PepperDash.Essentials.Core
{
 /// <summary>
 /// Represents a SmartObjectJoinOffsets
 /// </summary>
	public class SmartObjectJoinOffsets
	{
		public const ushort Dpad = 1;
		public const ushort Numpad = 2;

		public const ushort PresetList = 6;
	}
}