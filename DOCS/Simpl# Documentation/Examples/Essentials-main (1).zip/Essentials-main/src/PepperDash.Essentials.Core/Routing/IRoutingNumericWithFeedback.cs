﻿namespace PepperDash.Essentials.Core
{
    /// <summary>
    /// Defines the contract for IRoutingNumericWithFeedback
    /// </summary>
    public interface IRoutingNumericWithFeedback : IRoutingNumeric, IRoutingFeedback
    {
    }
}