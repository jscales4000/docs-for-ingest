﻿namespace PepperDash.Essentials.Core
{
    /// <summary>
    /// Defines the contract for IRmcRoutingWithFeedback
    /// </summary>
    public interface IRmcRoutingWithFeedback : IRmcRouting
    {
    }
}