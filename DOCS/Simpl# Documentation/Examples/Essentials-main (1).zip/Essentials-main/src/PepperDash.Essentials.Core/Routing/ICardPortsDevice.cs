﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using Crestron.SimplSharp;

//using PepperDash.Core;

//namespace PepperDash.Essentials.Core
//{
//    /// <summary>
//    /// Defines a class that has cards, like a DM chassis controller, where
//    /// we need to access ports on those cards
//    /// </summary>
//    public interface ICardPortsDevice : IKeyed
//    {
//        RoutingInputPort GetChildInputPort(string card, string port);
//        RoutingOutputPort GetChildOutputPort(string card, string port);
//    }
//}