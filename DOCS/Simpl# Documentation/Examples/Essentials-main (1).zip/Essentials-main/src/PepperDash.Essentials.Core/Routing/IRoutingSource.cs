﻿namespace PepperDash.Essentials.Core
{
    /// <summary>
    /// Defines the contract for IRoutingSource
    /// </summary>
    public interface IRoutingSource : IRoutingOutputs
    {
    }
}