﻿namespace PepperDash.Essentials.Core
{
    /// <summary>
    /// Defines the contract for ITxRoutingWithFeedback
    /// </summary>
    public interface ITxRoutingWithFeedback : ITxRouting
    {
    }
}