﻿//using System;
//using System.Collections.Generic;
//using Crestron.SimplSharpPro;
//using Crestron.SimplSharpPro.DeviceSupport;

//using PepperDash.Core;


//namespace PepperDash.Essentials.Core
//{
//    public interface IPresentationSource : IKeyed
//    {
//        string Name { get; }
//        PresentationSourceType Type { get; }
//        string IconName { get; set; }
//        BoolFeedback HasPowerOnFeedback { get; }
		
//    }
//}