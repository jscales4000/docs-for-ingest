using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharp.CrestronIO;       // For File Access and Information
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharpPro.GeneralIO;     // For IR Control
using Crestron.SimplSharpPro.Keypads;       // For Keypads
using System;

namespace CrestronIRExample
{
    public class ControlSystem : CrestronControlSystem
    {
        // Define our containers for our hardware
        private IROutputPort myPort;

        private CenIoIr104 myCenIr;

        private C2nCbdP myKeypad;

        //Default Constructor, No hardware access here
        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        /*       Remember:  Hardware is only available for access After we leave The default constructor.
         *       Doing this in the following method allows us to access the hardware as soon as we instantiate it
         *       and register it if it needs registration
         */

        public override void InitializeSystem()
        {
            try
            {
                // Using a keypad here for input can be easily changed to a touch panel if the student
                // does not have a cresnet keypad available or is on a non cresnet enabled processor

                myKeypad = new C2nCbdP(0x25, this);
                myKeypad.ButtonStateChange += MyKeypad_ButtonStateChange;
                myKeypad.Register();

                // Get the local patch for the program and add to it our IR files name
                string IRPath = string.Format("{0}/AppleTV.ir", Directory.GetApplicationDirectory());
                CrestronConsole.PrintLine("#### IRPATH = {0}", IRPath);

                bool portSuccess = false;  // Success flag to detect if we were able to get a port

                // Check if we support IR out
                if (this.SupportsIROut)  // We support the hardware locally
                {
                    CrestronConsole.PrintLine("#### We support IR on the device");
                    // Register the Controllers IR output slot
                    if (ControllerIROutputSlot.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                    {
                        ErrorLog.Error("Unable to register IR output slot {0}",
                            ControllerIROutputSlot.DeviceUnRegistrationFailureReason); ;
                    }
                    else
                    {
                        CrestronConsole.PrintLine("#### Registered the local port Success");
                        myPort = IROutputPorts[1];  // We take the first port
                        portSuccess = true;
                    }
                }
                else
                {
                    // Processor did not have IR ports, but we still need them.
                    myCenIr = new CenIoIr104(0x14, this);
                    if (myCenIr.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                    {
                        ErrorLog.Error("Failed to Register Cen-Io-Ir for reason: {0}",
                            myCenIr.RegistrationFailureReason);
                    }
                    else
                    {
                        CrestronConsole.PrintLine("#### Registered the port on a CenIoIr104 Success");
                        myPort = myCenIr.IROutputPorts[1]; // we take the first port
                        portSuccess = true;
                    }
                }
                // We now check if we were able to register a port and if so load  the IR file
                CrestronConsole.PrintLine("PortSuccess = {0}", portSuccess);

                if (portSuccess) // WE actually got a port to register, we can load the file
                {
                    // Lets load the IR File
                    myPort.LoadIRDriver(IRPath);

                    // List out the standard commands in the file
                    foreach (string s in myPort.AvailableStandardIRCmds())
                        CrestronConsole.PrintLine("AppleTV STD: {0}", s);

                    // List out ALL commands in the file
                    foreach (string s in myPort.AvailableIRCmds())
                        CrestronConsole.PrintLine("AppleTV IR: {0}", s);
                }
            }
            catch (Exception e)
            {
                CrestronConsole.PrintLine("Error in InitializeSystem: {0}", e.Message);
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        // Keypad button press handler.  Hardware and Code be switched to a touch panel if no keypad is available
        private void MyKeypad_ButtonStateChange(GenericBase device, ButtonEventArgs args)
        {
            CrestronConsole.PrintLine("Keypad ID: {0:X}, ButtonNo: {1}, ButtonState: {2}",
                device.ID, args.Button.Number, args.Button.State);

            /* NOTE:  IR Output has 3 modes of operation.
                myPort.Press()
                myPort.Release()
                myPort.PressAndRelease()
                Press and separate Release work great for a press and held buttons like
                Volume, Channel, and Arrows
                PressAndRelease will send a single command based on the IR files
                repeat setting and are great for power, play, pause, numbers
            */

            if (args.Button.State == eButtonState.Pressed)
            {
                switch (args.Button.Number)
                {
                    case 2:
                        myPort.PressAndRelease("PLAY", 25);  // Pulse for 25ms
                        break;

                    case 3:
                        myPort.Press("UP_ARROW"); // Start Transmitting the IR code
                        break;

                    case 4:
                        myPort.Press("DN_ARROW");
                        break;

                    default:
                        CrestronConsole.PrintLine("Key Not Programmed: {0}", args.Button.Number);
                        break;
                }
            }
            if (args.Button.State == eButtonState.Released)
            {
                myPort.Release();  // Stop transmitting the IR code
            }
        }
    }
}