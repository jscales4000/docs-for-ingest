﻿using System.Reflection;

[assembly: AssemblyTitle("XSigUtility")]
[assembly: AssemblyCompany("TBD Enterprises Inc.")]
[assembly: AssemblyProduct("XSigUtility")]
[assembly: AssemblyCopyright("Copyright © Troy Garner 2020")]
[assembly: AssemblyVersion("1.0.*")]

