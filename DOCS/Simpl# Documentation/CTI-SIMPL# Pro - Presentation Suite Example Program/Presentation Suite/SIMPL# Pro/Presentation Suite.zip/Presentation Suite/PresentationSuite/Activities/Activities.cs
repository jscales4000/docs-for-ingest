﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;

namespace PresentationSuite
{
    public class Activities
    {
        #region Fields
        string activityName;                            //Used for storing the activities name
        string deviceLocation;                          //Used for storing the device location
        bool isControllable;                            //Flag for whether the activity is controllable
        bool isSource;                                  //Flag for whether the activity is a source
        int inputNumber;                                //Used for storing which input the activity is connected to
        int controlPage;                                //Used for storing the subpage join number for controlling this source
        static int numActivities;                       //Static field for storing how many activities were added
        #endregion

        /*  Constructor
         *      When the class is instantiated all the fields are updated with the passed in values
         *      The constructor also checks for whether the IsSource flag is high, and if it is high, all source related fields are also updated
         *      Finally the numActivites is incremented
         */ 
        public Activities(string ActivityName, int ControlPageNumber, bool IsSource, bool IsControllable, string DeviceLocation, int InputNumber)
        {
            activityName = ActivityName;
            controlPage = ControlPageNumber;

            if (IsSource)
            {
                isSource = IsSource;
                inputNumber = InputNumber;
                isControllable = IsControllable;
                deviceLocation = DeviceLocation;
            }

            numActivities++;
        }

        #region Properties -- For accessing the fields for this Activity
        public int InputNumber
        {
            get
            {
                return inputNumber;
            }
        }

        public int ControlPage
        {
            get
            {
                return controlPage;
            }
        }

        public bool IsControllable
        {
            get
            {
                return isControllable;
            }
        }

        public bool IsSource
        {
            get
            {
                return isSource;
            }
        }

        public string ActivityName
        {
            get
            {
                return activityName;
            }
        }

        public int NumberOfActivities
        {
            get
            {
                return numActivities;
            }
        }
        #endregion
    }
}