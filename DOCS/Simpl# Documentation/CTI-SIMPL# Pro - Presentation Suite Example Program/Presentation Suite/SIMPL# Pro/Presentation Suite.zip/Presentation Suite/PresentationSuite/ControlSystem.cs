using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Crestron.SimplSharp;                          	
using Crestron.SimplSharp.CrestronIO;
using Crestron.SimplSharp.Reflection;                           //Access to Reflection
using Crestron.SimplSharpPro;                       	
using Crestron.SimplSharpPro.CrestronThread;        	        
using Crestron.SimplSharpPro.Diagnostics;		    	
using Crestron.SimplSharpPro.DeviceSupport;         	
using Crestron.SimplSharpPro.GeneralIO;
using Crestron.SimplSharpPro.DM;                                //Access to DM Chassis
using Crestron.SimplSharpPro.DM.Cards;                          //Access to DM Cards
using Crestron.SimplSharpPro.DM.Endpoints.Receivers;            //Access to DM Receivers
using Crestron.SimplSharpPro.Keypads;                           //Access to Keypad
using Crestron.SimplSharpPro.Lighting;                          //Access to Lighting devices
using Crestron.SimplSharpPro.Lighting.Din;                      //Access to DIN Rail Mounted Lighting devices
using Crestron.SimplSharpPro.Shades;                            //Access to UI devices
using Crestron.SimplSharpPro.UI;                                //Access to UI devices
using Crestron.RAD.DeviceTypes.BlurayPlayer;                    //All the RAD using statements are used for integration of Crestron Certified Driver
using Crestron.RAD.Drivers.BlurayPlayers;
using Crestron.RAD.Drivers.CableBoxes;
using Crestron.RAD.DeviceTypes.CableBox;
using Crestron.RAD.Common;      
using Crestron.RAD.Common.Enums;
using Crestron.RAD.Common.Interfaces;
using Crestron.RAD.ProTransports;
using PresentationSuite.Volume;                                 //Using statement for a location within this namespace

namespace PresentationSuite
{
    public class ControlSystem : CrestronControlSystem
    {
        #region System Devices
        Ts1542C TP01;                                                   //Crestron TS1542-C 15" Touch Panel
        C2nCbdP KP01;                                                   //Crestron C2N-CBD-P Keypad
        DmMd8x8 DMSW1;                                                  //Crestron DM 8X8 Chassis
        Dmc4kCoHdSingle DMOutputCard1;                                  //Crestron DM Chassis Output Card
        DmRmc4kScalerC RMC01;                                           //Crestron Projector 4K Scaler
        CsaPws10sHubEnet shadePowerSupply;                              //Crestron Shade Power Supply
        CsmQmtdc2562Cn SH01;                                            //Crestron Shade Motor
        Din4Dimflv4 DIM01;                                              //Crestron Lighting Dimmer
        #endregion

        #region Projector Screen
        CTimer screenUp;                                                //Timer for latching Projector Screen Up Relay
        CTimer screenDown;                                              //Timer for latching Projector Screen Down Relay
        bool screenOrientation;                                         //Boolean Value to track last orientation of the Projector Screen
        Relay screenUpRelay;                                            //Relay for raising screen
        Relay screenDownRelay;                                          //Relay for lowering screen
        #endregion

        #region Projector State
        bool ProjectorState;                                            //Boolean Value to store the State of the Projector (Powered On / Off)
        #endregion

        #region Devices
        #region For using Crestron Certified IR Devices
        /* Crestron Certified Drivers Overview
         * In an effort to simplify the integration of 3rd Party devices, Crestron Certified Drivers were created.
         * 
         *Crestron Certified Drivers, remove the necessity for a Programmer to develop every aspect of a Device.
         *The focus of the Programmer now moves to defining unique characteristics of the device, such as; 
         *  - Behaviour (Does it Provide Power Status Feedback? Does it have a Warm Up and Cool Down Time? If so, how long are they? etc...
         *  - Commands
         *  - Communication Port Numbers
         *
         * To allow for this, Crestron has developed a Framework.
         * In order for a Device, to be considered a Certified Driver, it must have certain information defined. 
         * The Framework is built in such a way to ensure that this is respected.
         * 
         * One of the challenges, is that there is a breadth of devices that may want to be integrated, and all of these devices do not share the same characteristics.
         * As an example, a Blu Ray player may have similar, but not all the characteristics of a Cable TV Receiver. The same can be said for a Video Server and a Projector.
         * To accomodate for this, categories of devices were created, which reflect their Device Type. These Device Types are:
         *      - AV Receiver
         *      - Blu Ray Player
         *      - Cable TV Box
         *      - Video Display
         *      - Video Server
         *      
         * Additionally, the way devices are controlled are also different, and just like with devices, different characteristics exist between the three primary methods of controlling a Device; IR, COM, and IP.
         * As an example, an IP Device will require for us to define the device's IP Address (or, in some scenarios Host Name) and Port Number, while an IR devices requires neither.
         * Just like for Devices, different Control Interfaces were created to accomodate for this. These are:
         *      - IR
         *      - COM
         *      - TCPIP
         *      
         */
        IIr irDriver;                                                   //Definition of Device Control Type - i.e. We want to Control an IR Device                                                                               
        IrPortTransport irDriverTransports;                             //Definition of IR Device Transports - i.e. the commands that are available for an IR Device

        IrBlurayPlayer bluRay1;                                         //Definition of the Type of IR Device - We want to control a BluRay player
        uint bluray1PortNum;                                            //Unsigned Integer to store the Number of the IR Port to which the BluRay Player is connected to
        string bluRay1DriverLocation;                                   //The loation of the Blu Ray players Driver (.ir) on the processor -- It is important to note that this .ir File is a Certified Driver compliant .ir driver

        IrBlurayPlayer bluRay2;
        uint bluray2PortNum;
        string bluRay2DriverLocation;
        #endregion

        #region Alternative Method of Controlling IR Devices
        /* Below is an alternative way of defining and controlling an IR Device.
         * As a result of not using the Crestron Certified Driver Framework, the process requires more information from the Programmer.
         * This is because, the device type information is not defined, and as a result the capabilities are not defined by a Framework, and will therefore require the programmer 
         * to integrate the device appropriately into the program.
         * 
         * Just like with a Crestron Certified Driver, a .ir file will need to be loaded to the processor and that .ir file is an IR file built within Device Learner.
         */
        uint cable1PortNum;                                             //Definition of the Type of IR Device - We want to control a Cable TV Receiver
        string cableTV1DriverLocation;                                  //The loation of the Blu Ray players Driver (.ir) on the processor
        #endregion

        IBasicVideoServer videoServer1;
        string videoServerIPAddress;                                    //Definition of the Type of Device - We want to control a Video Server
        string videoServerDriverLocation;                               //Definition of the location of the Device Driver - Note! This will be a .dll as this device will not be IR controlled
        byte videoServer1ID;                                            //Definition of the Unique ID for this Device, in Byte format

        BobsProjector proj01;                                           //Definition of the Projector Class, which will be used to Control a Projector using a class defined within this Solution (Projector/BobsProjector.cs)
        #endregion

        #region CablePresets
        List<ushort> satPresets = new List<ushort>();                   //Definition of a List, which will be used for Recalling Satellite Presets
        CMutex satPresetsMutex;                                         //Definition of a CMutex, this will be used to ensure that only one Preset is recalled at a time                                                                       //by only making the SatPresetsThread accessible one at a time
        #endregion

        #region Lighting Controls
        List<DinFluorescentBallasts> presetLoads;                       //Definition of a List, which will be used for storing all the Loads in the System, this will also be used for recalling Lighting Presets
        LightingPresets systemLightingPresets;                          //Definition of the LightingPreset class defined in Lighting\LightingControls.cs
        SigGroup lightingSigGroup;                                      //Definition of a Signal Group, used for tracking the level of a single Lighting Load
        #endregion

        #region Navigation
        List<Activities> systemActivities;                              //Defition of a List, which will contain all the Activites in the system
        uint selectedSource;                                            //Integer used for tracking which Source has been selected
        #endregion

        #region Volume Controls
        ushort volLevel;                                                //Ushort value, used for storing the current volume level
        VolumeControls systemVolumeControls;                            //Definition of Volume Controls class for Volume Controls and Volume Preset Recalling
        SigGroup volumeSigGroup;                                        //Definition of a Signal Group, used for tracking the current Volume Level
        Thread volumeFeedbackThread;                                    //Definition of a Thread, used for setting the feedback of which Volume Preset was selected
        CCriticalSection volumeFeedbackCC;                                    //Definition of a CEvent for the volumeFeedbackThread, this ensures that 
        #endregion

        #region Shade Controls
        bool startShadeThread;                                              //Flag used for controlling while loop in Thread
        Thread shadeFeedbackUpdater;                                        //Definition of a Thread, used for processing the current Shade Level
        SigGroup shadeSigGroup;                                             //Definition of a Signal Group, used for tracking the current Shade Level
        #endregion

        #region Processor Instantiation
        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 15;

                CrestronEnvironment.ProgramStatusEventHandler += new ProgramStatusEventHandler(ControlSystem_ControllerProgramEventHandler);        //Subscribe to the controller events (Program)

                systemActivities = new List<Activities>();                                                                                          //Instantiation of the systemActivites List
                lightingSigGroup = CreateSigGroup(1, eSigType.UShort);                                                                              //Sig Group to track Lighting Load level for TP gauge
                volumeSigGroup = CreateSigGroup(2, eSigType.UShort);                                                                                //Sig Group to track Volume Level for TP gauge 
                shadeSigGroup = CreateSigGroup(3, eSigType.UShort);                                                                                 //Sig Group to track Shade Level for TP Shade Object

                #region IR Devices
                if (this.IROutputPorts.Count >= 3)                                                                                                  //Verify that the Processor has at least 3 IR ports
                {
                    if (ControllerIROutputSlot.Register() == eDeviceRegistrationUnRegistrationResponse.Success)                                     //Register the IR Output SLOT of the processor
                    {
                        bluRay1DriverLocation = string.Format(@"{0}\Devices\BDPSeries.ir", Directory.GetApplicationDirectory());                    //Specification of BluRay1 driver location
                        bluRay2DriverLocation = bluRay1DriverLocation;                                                                              //Specification of BluRay2 driver location
                        cableTV1DriverLocation = string.Format(@"{0}\Devices\HR24.ir", Directory.GetApplicationDirectory()); ;                      //Specification of CableTV driver location

                        cable1PortNum = 1;                                                                                                          //Set Cable TV 1's Port Number to 1
                        this.IROutputPorts[cable1PortNum].LoadIRDriver(cableTV1DriverLocation);                                                     //Load the Driver to Cabe TV 1's IR Port

                        bluRay1 = new IrBlurayPlayer();                                                                                             //Instantiate bluRay1 IrBluRayPlayer
                        bluray1PortNum = 2;                                                                                                         //Set Blu Ray 1's Port Number to 2
                        irDriver = (IIr)bluRay1;                                                                                                    //Set the IR Driver to bluRay1 which is explicitly cast as a type IIr
                        irDriverTransports = new IrPortTransport(this.IROutputPorts[bluray1PortNum]);                                               //Instantiate the IR Driver Transports, setting Blu Ray 1's Transports to use irDriverTransports
                        irDriver.Initialize(irDriverTransports, bluRay1DriverLocation);                                                             //Initialize the IR Driver

                        bluRay2 = new IrBlurayPlayer();
                        bluray2PortNum = 3;
                        irDriver = (IIr)bluRay2;
                        irDriverTransports = new IrPortTransport(this.IROutputPorts[bluray2PortNum]);
                        irDriver.Initialize(irDriverTransports, bluRay2DriverLocation);
                    }
                }
                #endregion

                #region IP Devices
                if (this.SupportsEthernet)                                                                                                          //Verify that the Processor Supports Ethernet
                {
                    videoServerDriverLocation = string.Format(@"{0}\Devices\RokuUltra.dll", Directory.GetApplicationDirectory());                   //Definition of the location of the Video Server Driver
                    videoServerIPAddress = "10.64.56.139";                                                                                          //Definition of the IP Address of the Device
                    videoServer1ID = 1;                                                                                                             //Definition of the devices, ID

                    videoServer1 = GetVideoServerAssembly<IBasicVideoServer>(videoServerDriverLocation, "IBasicVideoServer", "ITcp");               //Loading of Video Server driver, please Reference GetVideoServerAssembly Class Below -- This uses Reflection

                    if (videoServer1 != null)                                                                                                       //Check to make sure that the Video Server Assembly was successfully obtained
                    {
                        ((ITcp)videoServer1).Initialize(IPAddress.Parse(videoServerIPAddress), ((ITcp)videoServer1).Port);                          //Initialize the Video Server as an IP Device

                        videoServer1.Id = videoServer1ID;                                                                                           //Set the ID of the Video Server

                        videoServer1.Connect();                                                                                                     //Connect to the Video Server
                    }
                }
                #endregion

                #region TS1542 Instantiation
                TP01 = new Ts1542C(0xF0, this);                                                                                                     //Instantiatie TP01, specifying its IP ID and the processor it will connect to
                TP01.Description = "Presentation Suite Touch Panel";
                TP01.SigChange += new SigEventHandler(TP01_SigChange);                                                                              //Subscribe TP01 to the SigChange Event handler, to monitor for user interaction with TP01
                TP01.OnlineStatusChange += new OnlineStatusChangeEventHandler(TP01_OnlineStatusChange);

                if (TP01.Register() != eDeviceRegistrationUnRegistrationResponse.Success)                                                           //Register TP01 with the processor, and verify whether the Registration was successful or not
                {
                    ErrorLog.Notice("Error Registering {0} with Processor, Reason: {1}", TP01.Name, TP01.RegistrationFailureReason);                //If it is not, log an Error Message
                }
                else                                                                                                                                //If the Touch Panel succesfully registers
                {
                    lightingSigGroup.Add(TP01.UShortInput[(uint)TP01AnalogJoins.lighting_Slider]);                                                  //Add one of the Touch Panel's Joins to the Lighting Sig Group
                    volumeSigGroup.Add(TP01.UShortInput[(uint)TP01AnalogJoins.volume_Slider]);                                                      //Add one of the Touch Panel's Joins to the Volume Sig Group
                    shadeSigGroup.Add(TP01.UShortInput[(uint)TP01AnalogJoins.shadeControl_ShadeController]);                                        //Add one of the Touch Panel's Joins to the Shade Sig Group
                    volLevel = TP01.UShortInput[(uint)TP01AnalogJoins.volume_Slider].UShortValue;                                                   //Add one of the Touch Panel's Joins to the Lighting Sig Group

                    string sgdFileLocation = string.Format(@"{0}\PresentationSuite_TS1542.sgd", Directory.GetApplicationDirectory());               //Definition of a String to store the location of the .sgd file on the processor
                    if (File.Exists(sgdFileLocation))                                                                                               //Verify that the File Exists
                    {
                        TP01.LoadSmartObjects(sgdFileLocation);                                                                                     //If it does, Load the SmartObjects contained in the .Sgd File to the Touch Panel
                        foreach (KeyValuePair<uint, SmartObject> so in TP01.SmartObjects)                                                           //Iterate through all the SmartObjects Loaded to the Touch Panel
                        {
                            ErrorLog.Notice("Smart Object {0} loaded", so.Value.ID);
                            so.Value.SigChange += new SmartObjectSigChangeEventHandler(Value_SigChange);                                            //Subscribe the Smart Object to SmartObjectSigChangeEventHandler, to trigger an event in the Program when someone interacts with the Smart Object
                        }
                        ResetTouchPanel();                                                                                                          //Call the ResetTouchPanel() method to reset the Touch Panel
                    }
                    else
                    {
                        ErrorLog.Error("Error Finding TouchPanel .SGD File, make sure it is being copied with your program");                       //If the File does not exist, Post an Error to the Error Log
                    }
                }
                #endregion

                #region C2N-CBD-P Instantiation
                KP01 = new C2nCbdP(0xF1, this);                                                                                                     //Instantiate KP01, specifying the Control Processor to connect to and its CNET ID
                KP01.ButtonStateChange += new ButtonEventHandler(KP01_ButtonStateChange);                                                           //Subscribe the KP to the ButtoEventHandler, for tracking of when something happens on the KP

                if (KP01.Register() != eDeviceRegistrationUnRegistrationResponse.Success)                                                           //Register the Keypad to the Processor
                {
                    ErrorLog.Notice("Error Registering {0} with Processor, Reason: {1}", KP01.Name, KP01.RegistrationFailureReason);                //If Registration Fails, log an Error
                }
                #endregion

                #region DM-MD8x8 Instantiation
                DMSW1 = new DmMd8x8(0xF1, this);                                                                                                            //Instantiate the DM Chassis Specifying its IP ID and Processor
                DMSW1.Description = "Presentation Suite Chassis";
                DMOutputCard1 = new Dmc4kCoHdSingle(1, DMSW1);                                                                                              //Instantiate a DM Output Card, specifying which Output Slot it is connected to, and the DM Chassis it is installed on

                RMC01 = new DmRmc4kScalerC(0xF2, DMSW1.Outputs[2]);                                                                                         //Instantiate a RoomBox specifying, its IP ID and the Output Port it is Connected to
                RMC01.Description = "Presentation Suite RMC";                                                                                               //Set the Description of the RoomBox
                RMC01.AudioOutput.OutputChange += new Crestron.SimplSharpPro.DM.Endpoints.EndpointAudioOutputChangeEventHandler(AudioOutput_OutputChange);  //Subscribe to the AudioOutput event to be informed of any changes in the device's volume
                RMC01.OnlineStatusChange += new OnlineStatusChangeEventHandler(RMC01_OnlineStatusChange);                                                   //Subscribe to the Online Status Change event

                RMC01.ComPorts[1].SetComPortSpec(ComPort.eComBaudRates.ComspecBaudRate19200,
                                                         ComPort.eComDataBits.ComspecDataBits8,
                                                         ComPort.eComParityType.ComspecParityEven,
                                                         ComPort.eComStopBits.ComspecStopBits2,
                                                         ComPort.eComProtocolType.ComspecProtocolRS232,
                                                         ComPort.eComHardwareHandshakeType.ComspecHardwareHandshakeNone,
                                                         ComPort.eComSoftwareHandshakeType.ComspecSoftwareHandshakeNone,
                                                         false);                                                                                            //Configure Port 1 on the RMC
                proj01 = new BobsProjector(RMC01.ComPorts[1]);                                                                                              //Instantiate the projector class, passing in the ComPort it is controlled by

                #region Screen Controls
                if (RMC01.RelayPorts.Count >= 2)                                                                                                     //Verify that the Processor has at least 2Relay ports 
                {
                    RMC01.RelayPorts[1].Register();                                                                                                 //Registering Relay Port 1 on the Room Controller
                    screenUpRelay = RMC01.RelayPorts[1];
                    RMC01.RelayPorts[2].Register();                                                                                                 //Registering Relay Port 2 on the Room Controller
                    screenDownRelay = RMC01.RelayPorts[2];
                    screenUp = new CTimer(ScreenUp, 200);                                                                                           //Instantiate a Timer (2 Seconds for Raising the Screen) - Reference ScreenUp Callback Function to see process that will be performed when the CTImer is Started                             
                    screenUp.Stop();                                                                                                                //Stop the Timer right after instantiation, so the Relay does not trigger
                    screenDown = new CTimer(ScreenDown, 200);                                                                                       //Instantiate a Timer (2 Seconds for Lowering the Screen) - Reference ScreenDown Callback Function to see process that will be performed when the CTImer is Started                             
                    screenDown.Stop();                                                                                                              //Stop the Timer right after instantiation, so the Relay does not trigger
                    ErrorLog.Error("Relays Registered");
                }
                #endregion

                if (DMSW1.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                {
                    ErrorLog.Notice("Error Registering {0} with Processor, Reason: {1}", DMSW1.Name, DMSW1.RegistrationFailureReason);
                }
                #endregion

                #region DIN-4DIM-FLV4 Instantiation
                DIM01 = new Din4Dimflv4(0xF0, this);                                                                                                //Instante the system;s Dimmer, specifying its CNET ID and Processor                                             

                if (DIM01.Register() != eDeviceRegistrationUnRegistrationResponse.Success)                                                          //Register the Device
                {
                    ErrorLog.Notice("Error Registering {0} with Processor, Reason: {1}", DIM01.Name, DIM01.RegistrationFailureReason);              //If it failes, log an Error
                }
                else
                {
                    presetLoads = new List<DinFluorescentBallasts>();                                                                               //If it is successful, instantiate presetLoads List
                    presetLoads.Add(DIM01.DinLoads[1]);                                                                                             //And add all the loads to the List;
                    presetLoads.Add(DIM01.DinLoads[2]);
                    presetLoads.Add(DIM01.DinLoads[3]);
                    presetLoads.Add(DIM01.DinLoads[4]);
                    systemLightingPresets = new LightingPresets(presetLoads, lightingSigGroup);                                                     //Finally Instantiate the LightingPresets Class, passing in the presetLoads and the Lighting Sig Group
                }

                #endregion

                #region Shade Instantiation
                shadePowerSupply = new CsaPws10sHubEnet(0xD0, this);                                                                                //First we instantiate the Shade Power Supply, assigning it an IP ID of D0      
                shadePowerSupply.Description = "Presentation Suite Shade Power Supply";                                                             //And assign it a Description for easier identification

                SH01 = new CsmQmtdc2562Cn(0x03, shadePowerSupply.Branches[2]);                                                                      //Before registering the Shade Power SupplyInstantiate the System Shade, specifying its CNET ID and processor
                SH01.BaseEvent += new BaseEventHandler(SH01_BaseEvent);                                                                             //Subscribe to the Shades Base Event to be informed of something happening

                if (shadePowerSupply.Register() != eDeviceRegistrationUnRegistrationResponse.Success)                                               //Register the Shade Power Supply
                {
                    ErrorLog.Error("Error Instantiating {0}, Reason: {1}", shadePowerSupply.Name, shadePowerSupply.RegistrationFailureReason);      //If it fails, Log an Error
                }

                #endregion
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        #endregion

        #region System Initialization
        public override void InitializeSystem()
        {
            try
            {
                ProjectorState = false;                                                                 //Set Projector State to Off
                screenOrientation = false;                                                              //Set Screen Orientation to Raised

                #region Define Lighting Presets
                systemLightingPresets.AddPreset(SimplSharpDeviceHelper.PercentToUshort(75), 100);       //Add Presets to List of Presets, Note the SimplSharpDeviceHelper used for converting a Percent Value to a Ushort
                systemLightingPresets.AddPreset(SimplSharpDeviceHelper.PercentToUshort(50), 100);
                systemLightingPresets.AddPreset(SimplSharpDeviceHelper.PercentToUshort(25), 100);
                systemLightingPresets.AddPreset(SimplSharpDeviceHelper.PercentToUshort(33), 100);
                systemLightingPresets.AddPreset(SimplSharpDeviceHelper.PercentToUshort(100), 100);
                systemLightingPresets.AddPreset(SimplSharpDeviceHelper.PercentToUshort(0), 100);
                #endregion

                #region Define Activities
                //Define the system Activites by instantiating a new "Activities" and adding it to the activites list

                systemActivities.Add(new Activities("Roku", (int)TP01DigitalsJoins.vtc_SubPage, true, true, "", 1));
                systemActivities.Add(new Activities("Laptop", (int)TP01DigitalsJoins.laptop_Subpage, true, false, "", 2));
                systemActivities.Add(new Activities("Satellite", (int)TP01DigitalsJoins.satellite_Subpage, true, true, "", 3));
                systemActivities.Add(new Activities("BluRay 1", (int)TP01DigitalsJoins.bluRay1_Subpage, true, true, "", 4));
                systemActivities.Add(new Activities("BluRay 2", (int)TP01DigitalsJoins.bluRay2_Subpage, true, true, "", 5));
                systemActivities.Add(new Activities("Shades", (int)TP01DigitalsJoins.shades_Subpage, false, false, "", 0));
                systemActivities.Add(new Activities("Weather", (int)TP01DigitalsJoins.weather_Subpage, false, false, "", 0));
                #endregion

                #region Satellite Presets
                //Instantiate the satPresets Mutex
                satPresetsMutex = new CMutex();

                //Add all the Satellite Presets to the satPresets Class
                satPresets.Add(40);
                satPresets.Add(41);
                satPresets.Add(34);
                satPresets.Add(55);
                satPresets.Add(161);
                satPresets.Add(12);
                satPresets.Add(8);
                satPresets.Add(4);
                #endregion

                #region Volume Controls
                systemVolumeControls = new VolumeControls(RMC01.AudioOutput.Volume, RMC01.AudioOutput.VolumeFeedback, 10000, 0, 65535, 50, 20, 200);                                               //Instantiaion of System Volume Controls - programming included in "Volume" folder
                systemVolumeControls.AddPreset((ushort)SimplSharpDeviceHelper.PercentToUshort(75), 200);                                                        //Add Volume Presets to systemVolumeControls
                systemVolumeControls.AddPreset((ushort)SimplSharpDeviceHelper.PercentToUshort(50), 200);
                systemVolumeControls.AddPreset((ushort)SimplSharpDeviceHelper.PercentToUshort(25), 200);
                systemVolumeControls.PresetCheckerEvent += new EventHandler<PresentationSuite.Volume.PresetCheckerEventArgs>(VolumeCtrls_PresetCheckerEvent);   //Subscribe to Preset Matching Event in systemVolumeControls                            
                volumeFeedbackCC = new CCriticalSection();                                                                                                 //Instantiate the CEvent for controlling when the Thread volumePresetFeedback will execute
                //Set the CEvent to Set allowing for the Thread to execute
                #endregion

                #region Shades
                startShadeThread = true;                                                                        //Set the Thread flag to True
                shadeFeedbackUpdater = new Thread(ShadeFeedback, null, Thread.eThreadStartOptions.Running);     //Initialize the shadeFeedback Thread and set it to running, this Thread is used for updating the Shade Object on the Touch Panel
                shadeFeedbackUpdater.Priority = Thread.eThreadPriority.MediumPriority;                          //Set the Thread priority to Medium
                #endregion

                volumeSigGroup.UShortValue = RMC01.AudioOutput.VolumeFeedback.UShortValue;              //Set the value of the volumeSigGroup, to the RMC's volume level
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }
        #endregion

        #region Screen Up

        /* Screen Up ThreadCallbackFunction
         * This method is called when the Screen is Raised.
         * The Following occurs:
         *      - Opens the Screen Down Relay, closes the Screen Up Relay
         *      - Then Updates the feedback on the TouchPanel
         *      - Wait 2seconds (2000ms)
         *      - opens the Screen Up Relay
         *      - Sets the Screen Orientation
         */
        public void ScreenUp(object o)
        {
            screenDownRelay.Open();
            screenUpRelay.Close();
            TP01.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 2 Select"].BoolValue = false;
            TP01.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 1 Select"].BoolValue = true;
            Thread.Sleep(2000);
            screenUpRelay.Open();
            screenOrientation = false;

        }
        #endregion

        #region Screen Down

        /*  Screen Down ThreadCallbackFunction
         *  Performs the same process, as the Screen Up ThreadCallbackFunction, but for Lowering the Screen
         */
        public void ScreenDown(object o)
        {
            screenUpRelay.Open();
            screenDownRelay.Close();
            TP01.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 1 Select"].BoolValue = false;
            TP01.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 2 Select"].BoolValue = true;
            Thread.Sleep(2000);
            screenDownRelay.Open();
            screenOrientation = true;

        }

        #endregion

        #region System Power Controls
        /*      SystemPower ThreadCallbackFunction
         *      This Method is called, whenever the system is Powered on or Off.
         *      The passed in parameter dictates if the system will be turned on or off
         *      It is explicitly cast as a Bool, so it can be used in the If statement for dictating the which process to run
         */ 
        public object SystemPower(object OnOrOff)
        {
            bool powerState = (bool)OnOrOff;
            if (powerState)                                                                                         //If the Power Flag is set high, run the Power on Sequence
            {

                
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitializationText_Set].BoolValue = false;          //Flip the Touch Panel Page to a Shutdown/Startup Page, with a Gauge
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitialization_PageFlip].BoolValue = true;
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitialization_PageFlip].BoolValue = false;
                TP01.UShortInput[(uint)TP01AnalogJoins.systemInitialization_Gauge].CreateRamp(65535, 540);          //Ramp the Gauge to 100% providing a progress bar

                this.IROutputPorts[cable1PortNum].Press("POWER_ON");                                                //Power on the Cable Receiver
                this.IROutputPorts[cable1PortNum].Release();                                    
                Thread.Sleep(200);                                                                                  //Wait 200ms
                bluRay1.PowerOn(IrActions.Pulse);                                                                   //Power On Blu Ray 1
                Thread.Sleep(200);                                                                                  //Wait 200ms
                bluRay2.PowerOn(IrActions.Pulse);                                                                   //Power On Blu Ray 2
                Thread.Sleep(5000);                                                                                 //Wait 5000ms
                TP01.BooleanInput[(uint)TP01DigitalsJoins.mainPg_PageFlip].BoolValue = true;                        //Flip To the Main Page
                TP01.BooleanInput[(uint)TP01DigitalsJoins.mainPg_PageFlip].BoolValue = false;
                TP01.UShortInput[(uint)TP01AnalogJoins.systemInitialization_Gauge].UShortValue = 0;                 //Reset the System Initialization Gauge
            }
            else                                                                                                    //If the Power Flag is low, run the Power Off Sequence
            {
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitializationText_Set].BoolValue = true;           //Flip the Touch Panel Page to a Shutdown/Startup Page, with a Gauge
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitialization_PageFlip].BoolValue = true;
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitialization_PageFlip].BoolValue = false;
                TP01.UShortInput[(uint)TP01AnalogJoins.systemInitialization_Gauge].CreateRamp(65535, 3040);         //Ramp the Gauge to 100% providing a progress bar
                ResetTouchPanel();                                                                                  //Reset the Touch Panel
                proj01.PowerOff();                                                                                  //Power Off the Projector
                ProjectorState = false;                                                                             //Set the Projector State to False (Off)

                if (screenOrientation)                                                                              //Check the Screen Orientation, is it is lowered
                {
                    screenUp.Reset();                                                                               //Raise the projector screen
                }
                this.IROutputPorts[cable1PortNum].Press("POWER_OFF");                                               //Power Off the Cable Receiver
                this.IROutputPorts[cable1PortNum].Release();
                Thread.Sleep(200);                                                                                  //Wait 200ms
                bluRay1.PowerOff(IrActions.Pulse);                                                                  //Power Off Blu Ray 1
                Thread.Sleep(200);                                                                                  //Wait 200ms
                bluRay2.PowerOff(IrActions.Pulse);                                                                  //Power Off Blu Ray 2
                Thread.Sleep(30000);                                                                                //Wait 30000ms
                DMSW1.VideoEnter.BoolValue = true;                                                                  //Set the Video Enter to High
                DMSW1.Outputs[1].VideoOut = null;                                                                   //Clear Output 1's Route
                DMSW1.Outputs[2].VideoOut = null;                                                                   //Clear Output 2's Route
                DMSW1.VideoEnter.BoolValue = false;                                                                 //Set Video Enter to Low
                TP01.BooleanInput[(uint)TP01DigitalsJoins.startPg_PageFlip].BoolValue = true;                       //Flip to the start Page
                TP01.BooleanInput[(uint)TP01DigitalsJoins.startPg_PageFlip].BoolValue = false;                  
                TP01.UShortInput[(uint)TP01AnalogJoins.systemInitialization_Gauge].UShortValue = 0;                 //Reset the System Initialization Gauge

            }

            return false;
        }
        #endregion

        #region Reset Touchpanel
        /*  Method for resetting the TouchPanel
        */
        public void ResetTouchPanel()
        {
            foreach (BoolInputSig input in TP01.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput)          //Set the feedback for tha Activity Select Smart Object to Low
            {
                input.BoolValue = false;
            }
            TP01.StringInput[(uint)TP01SerialJoins.audienceSource_Text].StringValue = "";                                       //Clear the Audience is Viewing Text
            TP01.StringInput[(uint)TP01SerialJoins.previewSource_Text].StringValue = "";                                        //Clear the Preview Source Text
            TP01.UShortInput[(uint)TP01AnalogJoins.audienceSource_Icon].UShortValue = 0;                                        //Set the Audience Icon to 0, which is blank
            TP01.UShortInput[(uint)TP01AnalogJoins.previewSource_Icon].UShortValue = 0;                                         //Set the Preview Icon to 0, which is blank
        }
        #endregion

        #region Send To Projector
        /*  ThreadCallbackFunction for sending whatever source is routed to the Preview Monitor to the Audience
         *  It also, sets up the projector and projector screen for use
         */ 
        public object SendToProjector(object o)
        {
            if (!ProjectorState)
            {
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitialization_PageFlip].BoolValue = true;                      //Flip to the System Initialization Page
                TP01.BooleanInput[(uint)TP01DigitalsJoins.systemInitialization_PageFlip].BoolValue = false;     
                TP01.UShortInput[(uint)TP01AnalogJoins.systemInitialization_Gauge].CreateRamp(65535, 3020);                     //Start Ramping the System Initialization Gauge
                
                if (!screenOrientation)                                                                                         //Check the Screen Orientation
                {
                    screenDown.Reset();                                                                                         //If it is raised, Lower the Screen
                }

                if (!ProjectorState)                                                                                            //Check the Projector State
                {
                    proj01.PowerOn();                                                                                           //If it is not On, Power it On
                    ProjectorState = true;                                                                                      //and set the Projector State to True
                }
                Thread.Sleep(30000);                                                                                            //Wait 30000ms for the projector to "Warm Up" and boot
                proj01.SetInput(BobsProjector.eInputName.HDMI1);                                                                //Set the projectors input source
                Thread.Sleep(2000);                                                                                             //Wait 2000ms
                TP01.BooleanInput[(uint)TP01DigitalsJoins.mainPg_PageFlip].BoolValue = true;                                    //Flip to the Main page
                TP01.BooleanInput[(uint)TP01DigitalsJoins.mainPg_PageFlip].BoolValue = false;
                TP01.UShortInput[(uint)TP01AnalogJoins.systemInitialization_Gauge].UShortValue = 0;                             //Reset the System Initialization Gauge
            }
            return 0;
        }
        #endregion

        #region Satellite Recall Preset ThreadCallbackFunction
        /* Satellite Preset Recall ThreadCallbackFunction
         * This method is called whenever a Satellite Preset needs to be recalled
         */
 
        public object RecallPreset(object ChannelNumber)
        {
            try
            {
                satPresetsMutex.WaitForMutex(1000);                                     //When this threadCallbackFunction is called, the CMutex gets set, so that this code snippet cannot be run more than once at a time
                ushort channelNumber = (ushort)ChannelNumber;                           //Explicitly cast the Passed in Parameter (Channel Number) to a ushort
                string sChannelNumber = Convert.ToString(channelNumber);                //Convert the channelNumber to a String

                foreach (char num in sChannelNumber)                                    //Iterate through each char in the ChannelNumber string
                {
                    string tempNumber = num.ToString();                                 //Convert the Char to a String
                    this.IROutputPorts[cable1PortNum].Press(tempNumber);                //Send that channel number IR Command to the Cable Box
                    Thread.Sleep(200);                                                  //Wait 200ms
                    this.IROutputPorts[cable1PortNum].Release();                        //Stop sending the command
                }
                this.IROutputPorts[cable1PortNum].PressAndRelease("ENTER", 200);        //After iterating through all the channel numbers, send the enter command
            }
            catch (Exception e)
            {

                ErrorLog.Notice("Error Recalling Preset {0}, Reason: {1}", (string)ChannelNumber, e.Message);
            }
            satPresetsMutex.ReleaseMutex();                                             //Release the CMutex so the threadCallbackFunction can be called again
            return null;
        }
        #endregion

        #region Volume Feedback Updated ThreadCallbackFunction
        /* Volume Feedback Update Callback Thread, used for updating the Volume Gauge on the Touch Panel
         * 
         */ 
        public object VolumeFeedbackUpdater(object VolumeLevel)
        {
            volumeFeedbackCC.Enter();                                   //CCritical Section is used to ensure that multiple Threads are not spooled up
            volumeSigGroup.UShortValue = (ushort)VolumeLevel;           //The Sig Group value then gets updated to the passed in VolumeLevel
            volumeFeedbackCC.Leave();                                   //The CCRitical Leave() method is called, allowing for this ThreadCallbackFunction to be run again
            return VolumeLevel;
        }
        #endregion

        #region ShadeFeedback ThreadCallBackFunction
        /*  Thread Callback Method used for updating the Shade Object on the Touch Panel to the current position of the Shade
         * 
         */ 
        public object ShadeFeedback(object NotUsed)
        {
            try
            {
                while (startShadeThread)                                                                //Flag to Control, when this thread will run indefinitely
                {
                    shadeSigGroup.UShortValue = SH01.PositionFeedback.UShortValue;                      //Update the Sig Group to the Position of the Shade
                    Thread.Sleep(50);                                                                   //Wait 50ms, signifying that this thread will loop every 50ms
                }
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error in Shade Feedback Thread, Reason: {0}", e.Message);
            }
            return NotUsed;
        }
        #endregion

        #region Get Video Server Assembly Method
        private T GetVideoServerAssembly<T>(string FileName, string DeviceInterface, string DeviceTransport)
        {
            try
            {
                var videoServerDll = Assembly.LoadFrom(FileName);                                           //Load the Assembly (.dll) for the driver we want to load and store in a field of type var
                var videoServerTypes = videoServerDll.GetTypes();                                           //Get the Type of loaded .dll (passed into videoServerDll) and store it in a field of type var

                foreach (var vsType in videoServerTypes)                                                    //Iterate through all the Types found in the Assembly
                {
                    var videoServerInterfaces = vsType.GetInterfaces();                                     //Get the Interfaces of each of those types.

                    if (videoServerInterfaces.FirstOrDefault(x => x.Name == DeviceInterface) == null)       //If the Interface name does not equal value of DeviceInterface continue looping
                    {
                        continue;
                    }
                    if (videoServerInterfaces.FirstOrDefault(x => x.Name == DeviceTransport) != null)       //If it does
                    {
                        return (T)videoServerDll.CreateInstance(vsType.FullName);                           //Return an object of Type T, which will contain an Instance of the videoServer Assembly, using the Type which contains the expected Interface name
                    }
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error Getting Video Server Assmebly, Reason: {0}", e.Message);
            }
            return default(T);
        }
        #endregion

        #region Touch Panel Events for Tracking what was triggered
        /* TP Enumerations are used in replacement of Join Numbers, this makes it much easier to review the code later on
         */ 
        void TP01_SigChange(BasicTriList currentDevice, SigEventArgs args)
        {
            BasicTriListWithSmartObject activeTP = (BasicTriListWithSmartObject)currentDevice;          //we explicity cast the currentDevice to a BasicTriListWithSmartObjects, this is so we can make affect SmartObjects on the Sending device (TS1542)
            switch (args.Sig.Type)                                                                      //A switch case is used to see what type of Join was triggered
            {
                #region Digital Events
                case eSigType.Bool:
                    {
                        if (args.Sig.BoolValue == true)                                                 //When this Event is raised as a result of a Digital Join being affected, we will get information of the Press and Release. Here we are checking to make sure                                        
                                                                                                        //The object was Pressed (Rising Edge)
                        {   
                            switch (args.Sig.Number)                                                    //After ensuring, that the a digital join was triggered, and it was its Rising Edge, we perform another Switch case to see which join number was triggered
                            {
                                #region Power Controls
                                case (uint)TP01DigitalsJoins.startPg_Welcome_Press:                     //When the TouchPanel Start page is triggered
                                    {
                                        new Thread(SystemPower, true);                                  //Instantiate a new Thread, specify the callbackfunction as System Power and pass in true, so the Power on code portion is run
                                        activeTP.BooleanInput[(uint)TP01DigitalsJoins.mainPg_PageFlip].BoolValue = args.Sig.BoolValue;
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.powerPg_Confirm_Press:
                                    {
                                        new Thread(SystemPower, false);
                                        activeTP.BooleanInput[(uint)TP01DigitalsJoins.startPg_PageFlip].BoolValue = args.Sig.BoolValue;
                                        break;
                                    }
                                #endregion

                                #region Send Preview Source to Audience
                                case (uint)TP01DigitalsJoins.sendToAudience_Press:                                                                  //When the send to Audience button is pressed (Projector)
                                    {
                                        if (selectedSource != 0)                                                                                    //Check that a source has been selected
                                        {
                                            new Thread(SendToProjector, null);                                                                      //Run the Send to Projector Thread
                                            DMSW1.VideoEnter.BoolValue = true;                                                                      //Set VideoEnter High for the chassis
                                            DMSW1.Outputs[2].VideoOut = DMSW1.Inputs[(uint)systemActivities[(int)selectedSource - 1].InputNumber];  //Route the selected Source to the projector output
                                            DMSW1.VideoEnter.BoolValue = false;                                                                     //Set the VideoEnter Low for the chassis
                                            activeTP.StringInput[(uint)TP01SerialJoins.audienceSource_Text].StringValue = systemActivities[(int)selectedSource - 1].ActivityName;   //Update Audience is Viewing to the active source
                                            activeTP.UShortInput[(uint)TP01AnalogJoins.audienceSource_Icon].UShortValue = (ushort)selectedSource;                                   //Update Audience is Viewing icon to the appropriate icon
                                        }
                                        break;
                                    }
                                #endregion

                                #region BluRay Commands
                                /* For each of the BluRay Commands, we first verify which BluRay player out of the two is active, and send the command to the appropriate BluRay Player
                                *  We used a Crestron Certified Driver (drivers.crestron.io) for the Blu Ray players, as a result, we can leverage the interfaces used by
                                *  the Crestron Certified Drivers to send the appropriate command. Note how each of the Commands are Method calls on the appropriate bluRay instance
                                */ 

                                case (uint)TP01DigitalsJoins.bluRay_PopUpMenu_Btn:
                                    {
                                        if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                        {
                                            bluRay1.PopUpMenu();
                                        }
                                        else
                                        {
                                            bluRay2.PopUpMenu();
                                        }
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.bluRay_Return_Btn:
                                    {
                                        if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                        {
                                            bluRay1.Return();
                                        }
                                        else
                                        {
                                            bluRay2.Return();
                                        }
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.bluRay_Blue_Btn:
                                    {
                                        if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                        {
                                            bluRay1.ColorButton(ColorButtons.Blue);
                                        }
                                        else
                                        {
                                            bluRay2.ColorButton(ColorButtons.Blue);
                                        }
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.bluRay_Green_Btn:
                                    {
                                        if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                        {
                                            bluRay1.ColorButton(ColorButtons.Green);
                                        }
                                        else
                                        {
                                            bluRay2.ColorButton(ColorButtons.Green);
                                        }
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.bluRay_Yellow_Btn:
                                    {
                                        if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                        {
                                            bluRay1.ColorButton(ColorButtons.Yellow);
                                        }
                                        else
                                        {
                                            bluRay2.ColorButton(ColorButtons.Yellow);
                                        }
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.bluRay_Red_Btn:
                                    {
                                        if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                        {
                                            bluRay1.ColorButton(ColorButtons.Red);
                                        }
                                        else
                                        {
                                            bluRay2.ColorButton(ColorButtons.Red);
                                        }
                                        break;
                                    }
                                #endregion

                                #region Cable TV Commands
                                    /* The Cable TV Receiver was added to the Program, by loading the .ir Driver.
                                     *  Unlinke the Blu Ray Players, the commands that need to be sent are defined differently and we need to manually define the Commands
                                     *  and ensure that they exist in the .ir driver
                                     */ 
                                case (uint)TP01DigitalsJoins.cableTV_Guide:
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("GUIDE", 200);
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.cableTV_Exit:
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("EXIT", 200);
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.cableTV_Blue:
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("BLUE", 200);
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.cableTV_Green:
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("GREEN", 200);
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.cableTV_Yellow:
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("YELLOW", 200);
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.cableTV_Red:
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("RED", 200);
                                        break;
                                    }
                                #endregion
                                default:
                                    break;
                            }
                        }
                        else if (args.Sig.BoolValue == false)                                           //If a falling edge is registered
                        {
                            switch (args.Sig.Number)
                            {
                                case (uint)TP01DigitalsJoins.startPg_Welcome_Press:                     //Set the mainPg page flip to low (a pulse is only required for flipping a page), on the falling edge of the Start Page button
                                    {
                                        activeTP.BooleanInput[(uint)TP01DigitalsJoins.mainPg_PageFlip].BoolValue = args.Sig.BoolValue;
                                        break;
                                    }
                                case (uint)TP01DigitalsJoins.powerPg_Confirm_Press:                     //Do the equivalent when the powerPg_Confirm is released
                                    {
                                        activeTP.BooleanInput[(uint)TP01DigitalsJoins.startPg_PageFlip].BoolValue = args.Sig.BoolValue;
                                        break;
                                    }
                                default:
                                    break;
                            }
                        }
                    }
                    break;
                #endregion                
                default:
                    break;
            }
        }

        void Value_SigChange(GenericBase currentDevice, SmartObjectEventArgs args)
        {
            BasicTriListWithSmartObject activeTP = (BasicTriListWithSmartObject)currentDevice;          //The Current Device is explivitly cast as a BasicTrilistWithSmartObjects

            try
            {
                if (args.Sig.BoolValue == true)                                                         //Check to make sure that its a rising edge event
                {
                    #region Push
                    switch (args.SmartObjectArgs.ID)                                                    //Based on the SmartObject ID Number, run the appropriate piece of code
                    {
                        #region Activity Select
                        case (uint)TP01SmartObjects.activitySelect_VTab:
                            {
                                uint selectedActivity = args.Sig.Number / 2 + 1;                                                            //A little bit of Math is performed to get the index of the Activity based on the button pressed.
                                                                                                                                            //The signal Number for all the presses of the Smart Object are odd, dividng it by 2, will as a result give us the correct, zero-based index
                                if (systemActivities[(int)selectedActivity - 1].IsSource)                                                   //Check within the Activities list, if the activity is a source, and if it is
                                {
                                    selectedSource = selectedActivity;                                                                      //update the selected source
                                    DMSW1.VideoEnter.BoolValue = true;                                                                      //Set the Switch's Video Enter High
                                    DMSW1.Outputs[1].VideoOut = DMSW1.Inputs[(uint)systemActivities[(int)selectedSource - 1].InputNumber];  //Route the Preview Output to the selected source
                                    DMSW1.VideoEnter.BoolValue = false;                                                                     //Set the Switch's Video Enter Low
                                    activeTP.StringInput[(uint)TP01SerialJoins.previewSource_Text].StringValue = systemActivities[(int)selectedSource - 1].ActivityName;    //Update the Preview Source Name
                                    activeTP.UShortInput[(uint)TP01AnalogJoins.previewSource_Icon].UShortValue = (ushort)selectedSource;                                    //Update the Preview Source icon
                                }

                                #region Set TouchPanel Navigation  
                                /*  This somewhat mimics the behavior of an interlock, specifically, its Break before make behavior.
                                 *  When an activity is selected, we set the feedback for the Activity Selecte buttons and the Activity control subpages low
                                 *  And then set only appropriate Subpage visible and Activity Select button feedback high
                                 */ 
                                for (int i = 1; i <= systemActivities.Count; i++)
                                {
                                    activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput[string.Format("Tab Button {0} Select", i)].BoolValue = false;        
                                }

                                activeTP.BooleanInput[(uint)TP01DigitalsJoins.vtc_SubPage].BoolValue = false;
                                activeTP.BooleanInput[(uint)TP01DigitalsJoins.laptop_Subpage].BoolValue = false;
                                activeTP.BooleanInput[(uint)TP01DigitalsJoins.satellite_Subpage].BoolValue = false;
                                activeTP.BooleanInput[(uint)TP01DigitalsJoins.bluRay1_Subpage].BoolValue = false;
                                activeTP.BooleanInput[(uint)TP01DigitalsJoins.bluRay2_Subpage].BoolValue = false;
                                activeTP.BooleanInput[(uint)TP01DigitalsJoins.shades_Subpage].BoolValue = false;
                                activeTP.BooleanInput[(uint)TP01DigitalsJoins.weather_Subpage].BoolValue = false;

                                activeTP.BooleanInput[10 + (uint)(args.Sig.Number / 2)].BoolValue = true;
                                activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput[args.Sig.Name.Replace("Press", "Select")].BoolValue = true;
                                #endregion

                                break;
                            }
                        #endregion

                        #region Screen Controls
                            /*  This conditional statement, controls the feedback of the ScreenControl Smart Object and runs the appropriate ScreenControl Method to either raise or lower the shade
                             */ 
                        case (uint)TP01SmartObjects.screenCntrls_VTab:
                            {
                                if (args.Sig.Name.Contains("1"))
                                {
                                    screenDown.Stop();
                                    activeTP.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 2 Select"].BoolValue = false;
                                    screenUp.Reset();
                                    activeTP.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 1 Select"].BoolValue = true;
                                }
                                else if (args.Sig.Name.Contains("2"))
                                {
                                    screenUp.Stop();
                                    activeTP.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 1 Select"].BoolValue = false;
                                    screenDown.Reset();
                                    activeTP.SmartObjects[(uint)TP01SmartObjects.screenCntrls_VTab].BooleanInput["Tab Button 2 Select"].BoolValue = true;
                                }
                                break;
                            }
                        #endregion

                        #region Lighting Presets
                            /*  Used for recalling a Lighting Preset.
                             *  Feedback is set upon the Lighting Preset being requested, not once the Loads have reached the requested level
                             */
                        case (uint)TP01SmartObjects.lightingPresets_VTab:
                            {
                                for (int i = 1; i < 7; i++)
                                {
                                    activeTP.SmartObjects[(uint)TP01SmartObjects.lightingPresets_VTab].BooleanInput[string.Format("Tab Button {0} Select", i)].BoolValue = false;
                                }
                                activeTP.SmartObjects[(uint)TP01SmartObjects.lightingPresets_VTab].BooleanInput[args.Sig.Name.Replace("Press", "Select")].BoolValue = true;

                                systemLightingPresets.RecalPreset((int)args.Sig.Number / 2);
                                break;
                            }
                        #endregion

                        #region Volume Controls
                            /*  Used to raising, lowering and muting volume.
                             */ 
                        case (uint)TP01SmartObjects.volumeControls_VTab:
                            {
                                if (args.Sig.Name.Contains("1"))                //To identify which button of a Smart Object was triggered, we can look at the Signal Name (which is equivalent to the Smart Object Definition Signal Name in SIMPL Windows)
                                                                                //In this case, we are looking for it to contain the Number 1, which indicates that it is the first button
                                {                          
                                    systemVolumeControls.RaiseVolume();
                                }
                                else if (args.Sig.Name.Contains("2"))           //Lower Volume
                                {
                                    systemVolumeControls.LowerVolume();
                                }
                                else if (args.Sig.Name.Contains("3"))           // Mute Toggle
                                {
                                    activeTP.SmartObjects[(uint)TP01SmartObjects.volumeControls_VTab].BooleanInput["Tab Button 3 Select"].BoolValue = systemVolumeControls.MuteToggle(); //When setting the feedback on the Mute button, the Mute Method is called and the returned value of the Method Call is what is used to set the state of Mute
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.volumePresets_VTab:
                            {
                                systemVolumeControls.RecalPreset((int)args.Sig.Number / 2);         //Just like with the Activiy Select, to get the appropriate Preset Index to recall, we divide the Signal Number by 2.
                                break;
                            }
                        #endregion

                        #region Video Server Controls
                        case (uint)TP01SmartObjects.videoServer_DPad:
                            {
                                if (videoServer1.Connected)
                                {
                                    if (args.Sig.Name == "Up")                                          //As mentioned in the Volume Controls Section, the Signal Name is equivalent to the SmartObject Definition Signal name in SIMPL Windows.
                                                                                                        //For a DPad, the up Button of the SmartObject, is identified in SIMPL Windows by the "Up" Signal on the SmartObject, so we look for the signal name to equal that
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Up, CommandAction.Hold);  //When specifying the command to send, we have the option of using CommandAction, which allows us to mimic the button on the remote being held, i.e. resend the command over and over again until released.
                                    }
                                    else if (args.Sig.Name == "Down")
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Down, CommandAction.Hold);
                                    }
                                    else if (args.Sig.Name == "Left")
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Left, CommandAction.Hold);
                                    }
                                    else if (args.Sig.Name == "Right")
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Right, CommandAction.Hold);
                                    }
                                    else if (args.Sig.Name == "Select")
                                    {
                                        videoServer1.Select();
                                    }
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.videoServer_Trasnport1_HTab:
                            {
                                if (args.Sig.Name.Contains("1"))
                                {
                                    videoServer1.Home();
                                }
                                else if (args.Sig.Name.Contains("2"))
                                {
                                    videoServer1.Menu();
                                }
                                else if (args.Sig.Name.Contains("3"))
                                {
                                    videoServer1.Back();
                                }
                                else if (args.Sig.Name.Contains("4"))
                                {
                                    videoServer1.Repeat();
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.videoServer_Transport2_HTab:
                            {
                                if (args.Sig.Name.Contains("1"))
                                {
                                    videoServer1.KeypadBackSpace();
                                }
                                else if (args.Sig.Name.Contains("2"))
                                {
                                    videoServer1.Asterisk();
                                }
                                else if (args.Sig.Name.Contains("3"))
                                {
                                    videoServer1.ReverseScan();
                                }
                                else if (args.Sig.Name.Contains("4"))
                                {
                                    videoServer1.ForwardScan();
                                }
                                break;
                            }
                        #endregion

                        #region BluRay Controls

                            /* Similar to the Video Server Controls, however now we have a field for IrActions, which allows us to dictate the behavior of the IR Command being sent out
                             */ 
                        case (uint)TP01SmartObjects.bluRay_DPad:
                            {
                                if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                {
                                    if (args.Sig.Name.Contains("Up"))
                                    {
                                        bluRay1.ArrowKey(ArrowDirections.Up, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Down"))
                                    {
                                        bluRay1.ArrowKey(ArrowDirections.Down, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Left"))
                                    {
                                        bluRay1.ArrowKey(ArrowDirections.Left, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Right"))
                                    {
                                        bluRay1.ArrowKey(ArrowDirections.Right, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Select"))
                                    {
                                        bluRay1.Enter();
                                    }
                                }
                                else
                                {
                                    if (args.Sig.Name.Contains("Up"))
                                    {
                                        bluRay2.ArrowKey(ArrowDirections.Up, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Down"))
                                    {
                                        bluRay2.ArrowKey(ArrowDirections.Down, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Left"))
                                    {
                                        bluRay2.ArrowKey(ArrowDirections.Left, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Right"))
                                    {
                                        bluRay2.ArrowKey(ArrowDirections.Right, IrActions.Pulse);
                                    }
                                    else if (args.Sig.Name.Contains("Select"))
                                    {
                                        bluRay2.Enter();
                                    }
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.bluRay_Transport1_HTab:
                            {
                                if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                {
                                    if (args.Sig.Name.Contains("1"))
                                    {
                                        bluRay1.Play();
                                    }
                                    else if (args.Sig.Name.Contains("2"))
                                    {
                                        bluRay1.Stop();
                                    }
                                    else if (args.Sig.Name.Contains("3"))
                                    {
                                        bluRay1.Pause();
                                    }
                                    else if (args.Sig.Name.Contains("4"))
                                    {
                                        bluRay1.Eject();
                                    }
                                }
                                else
                                {
                                    if (args.Sig.Name.Contains("1"))
                                    {
                                        bluRay2.Play();
                                    }
                                    else if (args.Sig.Name.Contains("2"))
                                    {
                                        bluRay2.Stop();
                                    }
                                    else if (args.Sig.Name.Contains("3"))
                                    {
                                        bluRay2.Pause();
                                    }
                                    else if (args.Sig.Name.Contains("4"))
                                    {
                                        bluRay2.Eject();
                                    }
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.bluRay_Transports2_HTab:
                            {
                                if (activeTP.SmartObjects[(uint)TP01SmartObjects.activitySelect_VTab].BooleanInput["Tab Button 4 Select"].BoolValue == true)
                                {
                                    if (args.Sig.Name.Contains("1"))
                                    {
                                        bluRay1.ReverseSkip();
                                    }
                                    else if (args.Sig.Name.Contains("2"))
                                    {
                                        bluRay1.ReverseScan();
                                    }
                                    else if (args.Sig.Name.Contains("3"))
                                    {
                                        bluRay1.ForwardScan();
                                    }
                                    else if (args.Sig.Name.Contains("4"))
                                    {
                                        bluRay1.ForwardSkip();
                                    }
                                }
                                else
                                {
                                    if (args.Sig.Name.Contains("1"))
                                    {
                                        bluRay2.Play();
                                    }
                                    else if (args.Sig.Name.Contains("2"))
                                    {
                                        bluRay2.Stop();
                                    }
                                    else if (args.Sig.Name.Contains("3"))
                                    {
                                        bluRay2.Pause();
                                    }
                                    else if (args.Sig.Name.Contains("4"))
                                    {
                                        bluRay2.Eject();
                                    }
                                }
                                break;
                            }
                        #endregion

                        #region Cable TV Controls
                        case (uint)TP01SmartObjects.cableTV_DPad:
                            {
                                if (args.Sig.Name.Contains("Up"))
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease("UP_ARROW", 200);
                                }
                                else if (args.Sig.Name.Contains("Down"))
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease("DN_ARROW", 200);
                                }
                                else if (args.Sig.Name.Contains("Left"))
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease("LEFT_ARROW", 200);
                                }
                                else if (args.Sig.Name.Contains("Right"))
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease("RIGHT_ARROW", 200);
                                }
                                else if (args.Sig.Name.Contains("Select"))
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease("SELECT", 200);
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.cableTV_Channel:
                            {
                                if (args.Sig.Name.Contains("1"))
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease("CH+", 200);
                                }
                                else
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease("CH-", 200);
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.cableTV_Preset:
                            {
                                if (args.Sig.Name == "Item Clicked")
                                {
                                    uint presetNumber = args.SmartObjectArgs.UShortOutput["Item Clicked"].UShortValue;
                                    ErrorLog.Notice("Index: {0} Preset: {1}", presetNumber, satPresets[(int)presetNumber - 1].GetType());
                                    Thread volumePresetsThread = new Thread(RecallPreset, satPresets[(int)presetNumber - 1], Thread.eThreadStartOptions.Running);
                                }
                                break;
                            }
                        case (uint)TP01SmartObjects.cableTV_Keypad:
                            {
                                if (args.Sig.Name.Contains("-") || args.Sig.Name.Contains("Enter"))
                                {
                                    if (args.Sig.Name.Contains("-"))
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("Digit_-", 200);
                                    }
                                    else
                                    {
                                        this.IROutputPorts[cable1PortNum].PressAndRelease("ENTER", 200);
                                    }
                                }
                                else
                                {
                                    this.IROutputPorts[cable1PortNum].PressAndRelease(args.Sig.Name, 200);
                                }
                                break;
                            }
                        #endregion

                        #region Shade Controls
                        case (uint)TP01SmartObjects.shadesControls_VTab:
                            {
                                if (args.Sig.Name.Contains("1"))
                                {
                                    SH01.SetPosition(65535);
                                }
                                else if (args.Sig.Name.Contains("2"))
                                {
                                    SH01.SetPosition(0);
                                }
                                else if (args.Sig.Name.Contains("3"))
                                {
                                    SH01.Open();
                                }
                                else if (args.Sig.Name.Contains("4"))
                                {
                                    SH01.Stop();
                                }
                                else if (args.Sig.Name.Contains("5"))
                                {
                                    SH01.Close();
                                }
                                break;
                            }
                        #endregion

                        default:
                            break;
                    }
                    #endregion
                }
                else if (args.Sig.BoolValue == false)
                {
                    #region Release
                    /* When the Falling Edge of a Smart Object Digital is identified
                     */ 
                    switch (args.SmartObjectArgs.ID)
                    {
                        #region Volume Controls
                        case (uint)TP01SmartObjects.volumeControls_VTab:
                            {
                                if (args.Sig.Name.Contains("1") || args.Sig.Name.Contains("2"))         //If the Volume Up or Volume Down buttons were released
                                {      
                                    systemVolumeControls.CancelRamp();                                  //Cancel the Ramping of the volume
                                }
                                break;
                            }
                        #endregion

                        #region Video Server Controls
                        case (uint)TP01SmartObjects.videoServer_DPad:
                            {
                                if (videoServer1.Connected)                                             //Check that the connection to the Video Server is active
                                {                                  
                                    //Based on the button released, Release the Command (the press CommandAction was Hold)
                                    if (args.Sig.Name == "Up")
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Up, CommandAction.Release);
                                    }
                                    else if (args.Sig.Name == "Down")
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Down, CommandAction.Release);
                                    }
                                    else if (args.Sig.Name == "Left")
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Left, CommandAction.Release);
                                    }
                                    else if (args.Sig.Name == "Right")
                                    {
                                        videoServer1.ArrowKey(ArrowDirections.Right, CommandAction.Release);
                                    }
                                }
                                break;
                            }
                        #endregion

                        #region Shade Controls
                        case (uint)TP01SmartObjects.shadesControls_VTab:
                            {
                                if (args.Sig.Name.Contains("1") || args.Sig.Name.Contains("2"))         //If the Button released was Up or Down (buttons 1 or 2)
                                {
                                    SH01.Stop();                                                        //Stop the Shade
                                }
                                break;
                            }
                        #endregion

                        default:
                            break;
                    }
                    #endregion
                }
            }
            catch (Exception e)
            {

                ErrorLog.Notice("Error Processing Request, Reason: {0}", e.Message); ;
            }
        }

        #endregion

        #region Keypad Event for Tracking what was triggered
        void KP01_ButtonStateChange(GenericBase device, ButtonEventArgs args)
        {
            C2nCbdP activeKeypad = (C2nCbdP)device;
            KeypadFunctions.SetKeypadFeedback(args.Button.Number, ref activeKeypad);    //When a button is pressed, run the SetKeypadFeedback Method to set the appropriate Feedback High

            //Based on the Button Pressed, recall the appropariate Lighting Preset from the list of Presets
            switch (args.Button.Number)
            {
                case 1:
                    {
                        systemLightingPresets.RecalPreset(0);

                        break;
                    }
                case 2:
                    {
                        systemLightingPresets.RecalPreset(1);

                        break;
                    }
                case 3:
                    {
                        systemLightingPresets.RecalPreset(2);

                        break;
                    }
                case 4:
                    {
                        systemLightingPresets.RecalPreset(3);

                        break;
                    }
                case 5:
                    {
                        systemLightingPresets.RecalPreset(4);

                        break;
                    }
                case 6:
                    {
                        systemLightingPresets.RecalPreset(5);

                        break;
                    }
                default:
                    {
                        CrestronConsole.PrintLine("Preset not tied to Button {0}", args.Button.Number);
                    }
                    break;
            }
        }
        #endregion

        #region Volume Preset Feedback Event, for setting Touch Panel Feedback
        /*  This Method is called, whenever the PresetCheckerEvent is raised. 
         *  It allows for the VolumeControls to report back, and matches or lack of matches between the current volume level and one of the presets added
         */ 
        void VolumeCtrls_PresetCheckerEvent(object sender, PresentationSuite.Volume.PresetCheckerEventArgs e)
        {
            foreach (KeyValuePair<ushort, uint> preset in systemVolumeControls.PresetList)                                                                          //When the event is raised, first reset the feedback of all the volume Presets
            {
                int presetIndex = systemVolumeControls.PresetList.IndexOf(preset) + 1;
                TP01.SmartObjects[(uint)TP01SmartObjects.volumePresets_VTab].BooleanInput[string.Format("Tab Button {0} Select", presetIndex)].BoolValue = false;
            }

            if (e.MatchState)                                                                                                                                       //If a match is found
            {
                TP01.SmartObjects[(uint)TP01SmartObjects.volumePresets_VTab].BooleanInput[string.Format("Tab Button {0} Select", e.PresetIndex)].BoolValue = true;  //Set the feedback of that Preset to High
            }
        }
        #endregion

        #region Room RMC AudioOutput Change Event - triggered whenever the Output Volume changes
        /* Whenever the RMC reports that its volume has changed, instantiate the volumeFeedbackThread and pass in the relevant information.
         * Its important to note, that the volumeFeedbackThread has a CCriticalSection to control this process
         */ 
        void AudioOutput_OutputChange(Crestron.SimplSharpPro.DM.Endpoints.EndpointAudioOutput audioOutput, Crestron.SimplSharpPro.DM.Endpoints.AudioOutputEventArgs args)
        {
            volumeFeedbackThread = new Thread(VolumeFeedbackUpdater, audioOutput.VolumeFeedback.UShortValue, Thread.eThreadStartOptions.Running);
        }
        #endregion

        #region Room RMC OnlineStatus Change Event - triggered whenever the Connection Status changes
        /* Whenever the RMC's online status changes from Offline to online, updated the Volume of the RMC to the value of its Feedback
         * This will result in the volumeSigGroup being set correctly
         */ 
        void RMC01_OnlineStatusChange(GenericBase currentDevice, OnlineOfflineEventArgs args)
        {
            if (args.DeviceOnLine)
            {
                DmRmc4kScalerC tempRMC = (DmRmc4kScalerC)currentDevice;
                tempRMC.AudioOutput.Volume.UShortValue = tempRMC.AudioOutput.VolumeFeedback.UShortValue;
            }
        }
        #endregion

        #region Shade Base Event, This is triggered when something happens that no other Event Handles
        /*  The Shade being used does not have a dedicated event for when it is moving, as a result we use the Base Event
         *  When the base event is raised, we clear the feedback for Open, Stop and Close
         *  and then check to see if the Shade is Fully Opened, Fully Closed or Stopped and set the feedback appropriately
         */ 
        void SH01_BaseEvent(GenericBase device, BaseEventArgs args)
        {
            for (int i = 3; i <= 5; i++)
            {
                TP01.SmartObjects[(uint)TP01SmartObjects.shadesControls_VTab].BooleanInput[string.Format("Tab Button {0} Select", i)].BoolValue = false;
            }
            if (SH01.IsFullyOpened.BoolValue)
            {
                TP01.SmartObjects[(uint)TP01SmartObjects.shadesControls_VTab].BooleanInput["Tab Button 3 Select"].BoolValue = true;
            }
            else if (SH01.IsFullyClosed.BoolValue)
            {
                TP01.SmartObjects[(uint)TP01SmartObjects.shadesControls_VTab].BooleanInput["Tab Button 5 Select"].BoolValue = true;
            }
            else if (SH01.IsStopped.BoolValue)
            {
                TP01.SmartObjects[(uint)TP01SmartObjects.shadesControls_VTab].BooleanInput["Tab Button 4 Select"].BoolValue = true;
            }
        }
        #endregion

        #region Touch Panel Online Status Event, triggered whenever the Touchpanel goes online/offline
        /* When the Touch Panel comes online, update the text each of the Activity Select buttons, to the appropriate Activity
         * as defined in the systemActivites list
         */ 
        void TP01_OnlineStatusChange(GenericBase currentDevice, OnlineOfflineEventArgs args)
        {
            BasicTriListWithSmartObject tempTP = (BasicTriListWithSmartObject)currentDevice;

            if (args.DeviceOnLine)
            {
                for (int activity = 0; activity < systemActivities.Count; activity++)
                {
                    TP01.StringInput[(uint)(activity + 10)].StringValue = systemActivities[activity].ActivityName;
                }
            }
        }
        #endregion

        #region Processor Events
        void ControlSystem_ControllerProgramEventHandler(eProgramStatusEventType programStatusEventType)
        {
            switch (programStatusEventType)
            {
                case (eProgramStatusEventType.Paused):
                    break;
                case (eProgramStatusEventType.Resumed):
                    break;
                case (eProgramStatusEventType.Stopping):
                    startShadeThread = false;
                    break;
            }

        }
        #endregion
    }
}
