﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;

namespace PresentationSuite
{

    /* Touch Panel Analog Joins
     * Enumeration for all the Analog Joins for the Touch Panel, based on the VT Pro Project
     */ 
    public enum TP01AnalogJoins
    {
        lighting_Slider = 1,
        volume_Slider,
        audienceSource_Icon,
        previewSource_Icon,        
        systemInitialization_Gauge = 6,
        shadeControl_ShadeController = 20
    }

    /* Touch Panel Digital Joins
     * Enumeration for all the Digital Joins for the Touch Panel, based on the VT Pro Project
     */
    public enum TP01DigitalsJoins
    {
        startPg_Welcome_Press = 1,
        powerPg_Confirm_Press,
        mainPg_PageFlip,
        startPg_PageFlip,
        sendToAudience_Press,
        systemInitializationText_Set,
        systemInitialization_PageFlip,
        vtc_SubPage = 10,
        laptop_Subpage,
        satellite_Subpage,
        bluRay1_Subpage,
        bluRay2_Subpage,
        shades_Subpage,
        weather_Subpage,
        cableTV_Guide = 30,
        cableTV_Exit,
        cableTV_Blue,
        cableTV_Green,
        cableTV_Yellow,
        cableTV_Red,
        bluRay_PopUpMenu_Btn = 40,
        bluRay_Return_Btn,
        bluRay_Blue_Btn,
        bluRay_Green_Btn,
        bluRay_Yellow_Btn,
        bluRay_Red_Btn
    }

    /* Touch Panel Serial Joins
     * Enumeration for all the Serial Joins for the Touch Panel, based on the VT Pro Project
     */
    public enum TP01SerialJoins
    {
        audienceSource_Text = 3,
        previewSource_Text,
        activityOne_Text = 10,
        activityTwo_Text,
        activityThree_Text,
        activityFour_Text,
        activityFive_Text,
        activitySix_Text,
        activitySeven_Text
    }

    /* Touch Panel Smart Objects
     * Enumeration for all the Smart Objects for the Touch Panel, based on the VT Pro Project
     */
    public enum TP01SmartObjects
    {
        activitySelect_VTab = 1,
        screenCntrls_VTab,
        lightingPresets_VTab,
        volumeControls_VTab,
        volumePresets_VTab,
        shadesControls_VTab = 20,
        cableTV_DPad = 30,
        cableTV_Channel,
        cableTV_Preset,
        cableTV_Keypad,
        bluRay_DPad = 40,
        bluRay_Transport1_HTab,
        bluRay_Transports2_HTab,
        videoServer_DPad = 50,
        videoServer_Trasnport1_HTab,
        videoServer_Transport2_HTab,
    }
}