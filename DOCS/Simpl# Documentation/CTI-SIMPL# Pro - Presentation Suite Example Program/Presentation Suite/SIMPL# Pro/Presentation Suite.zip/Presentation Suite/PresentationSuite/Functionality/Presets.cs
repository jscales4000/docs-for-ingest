﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;

namespace PresentationSuite
{
    public class Preset
    {
        #region Fields
        List<KeyValuePair<ushort, uint>> presetList = new List<KeyValuePair<ushort, uint>>();               //Instantiation of presetList for storing the presets
        #endregion

        /*  PresetList Properties for getting the presetList
         */ 
        public List<KeyValuePair<ushort, uint>> PresetList
        {
            get
            {
                return presetList;                                                                      
            }
        }

        /* GetPresetValues Method
         * Used for getting the preset information from the presetList at the passed in Index
         */
        public KeyValuePair<ushort, uint> GetPresetValues(int Index)
        {
            try
            {
                return presetList[Index];
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error retrieving Preset at Index: {0}, Reason: 1", Index, e.Message);
                return new KeyValuePair<ushort, uint>(0, 0);
            }
        }

        /*  Virtual RecalPreset Method
         *  This method is defined as a Virtual Method, which allows for this Method to be overriden
         *  This Method is empty, and will need to be overriden by the programmer
         */ 
        public virtual void RecalPreset(int Index)
        {
        }

        /*  AddToPresetList Method
         *  Method for adding a Preset to the presetList
         *  The Method is protected, so it can only be used within this Class or a Class inheriting this class
         */ 
        protected void AddToPresetList(ushort PresetVaue, uint RampTime)
        {
            try
            {
                presetList.Add(new KeyValuePair<ushort, uint>(PresetVaue, RampTime));
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Unable to Add Preset, Reason: {0}", e.Message);
            }
        }

        /*  RemovePreset Method  
         *  Method for Removing a Preset from presetList
         */ 
        public void RemovePreset(int PresetIndex)
        {
            try
            {
                presetList.RemoveAt(PresetIndex);
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Unable to Remove Preset, Reason: {0}", e.Message);
            }
        }     
    }
}