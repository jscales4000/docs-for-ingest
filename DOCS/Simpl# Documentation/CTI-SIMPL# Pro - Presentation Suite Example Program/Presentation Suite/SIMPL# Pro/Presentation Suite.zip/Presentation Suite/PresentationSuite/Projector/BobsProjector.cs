﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharpPro;

namespace PresentationSuite
{
    public class BobsProjector
    {
        #region Fields
        List<string> inputCommands = new List<string>();                    //List of Input Commands
        List<string> powerCommands = new List<string>();                    //List of Power Commands
        ComPort deviceComPort;                                              //ComPort Projector is Connected to
        #endregion

        /* Bobs Projector Constructor
         * Default Constructor, that adds the list of Device Commands split into two categories:
         *      - Input Commands
         *      - Power Commands
         * Additionally, the Port to which the the Projector is connected to
         */
        public BobsProjector(ComPort ConnectedPort)
        {
            inputCommands.Add("\x02VID1\x03");
            inputCommands.Add("\x02VID2\x03");
            inputCommands.Add("\x02RGB\x03");
            inputCommands.Add("\x02HDM1\x03");
            inputCommands.Add("\x02HDM2\x03");
            powerCommands.Add("\x02PON\x03");
            powerCommands.Add("\x02POF\x03");
            deviceComPort = ConnectedPort;
        }

        /*  Set Input Method
         *  Send the Appropriate input command to Projectors Com Port
         */
        public void SetInput(eInputName Input)
        {
            try
            {
                switch (Input)
                {
                    case eInputName.Composite:
                        deviceComPort.Send(inputCommands[(int)eInputName.Composite]);
                        break;
                    case eInputName.Component:
                        deviceComPort.Send(inputCommands[(int)eInputName.Component]);
                        break;
                    case eInputName.VGA:
                        deviceComPort.Send(inputCommands[(int)eInputName.VGA]);
                        break;
                    case eInputName.HDMI1:
                        deviceComPort.Send(inputCommands[(int)eInputName.HDMI1]);
                        break;
                    case eInputName.HDMI2:
                        deviceComPort.Send(inputCommands[(int)eInputName.HDMI2]);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error Sending the input Command to the Projector, Reason: {0}", e.Message);
            }
            
        }

        /* Power On Method
         * Used for Powering On the Projector
         */
        public void PowerOn()
        {
            try
            {
                deviceComPort.Send(powerCommands[0]);
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error Powering on Projector, Reason: {0}", e.Message);                
            }            
        }

        /* Power Off Method
         * Used for Powering Off the Projector
         */
        public void PowerOff()
        {
            try
            {
                deviceComPort.Send(powerCommands[1]);
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error Powering off Projector, Reason: {0}", e.Message);
            }            
        }

        /* eInputName Enumeration
         * Enumeration for the Input Commands defined
         */
        public enum eInputName
        {
            Composite = 0,
            Component,
            VGA,
            HDMI1,
            HDMI2
        }

        /* ePowerCommands Enumeration
         * Enumeration for the Power Commands defined
         */
        public enum ePowerCommands
        {
            PowerOn = 0,
            PowerOff
        }
    }
}