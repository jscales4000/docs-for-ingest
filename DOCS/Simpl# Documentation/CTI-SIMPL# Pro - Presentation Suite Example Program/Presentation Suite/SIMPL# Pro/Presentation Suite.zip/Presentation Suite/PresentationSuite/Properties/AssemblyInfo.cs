﻿using System.Reflection;

[assembly: AssemblyTitle("PresentationSuite")]
[assembly: AssemblyCompany("Crestron Electronics, Inc.")]
[assembly: AssemblyProduct("PresentationSuite")]
[assembly: AssemblyCopyright("Copyright © Crestron Electronics, Inc. 2019")]
[assembly: AssemblyVersion("1.0.0.*")]

