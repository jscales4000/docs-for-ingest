﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharpPro.CrestronThread;
using Crestron.SimplSharpPro.DM.Endpoints.Receivers;
using Crestron.SimplSharpPro;


namespace PresentationSuite.Volume
{
    public class VolumeControls : Preset
    {

        /* Volume Controls
         * Info
         * > Volume Controls inherits Presets.cs, found under Functionality\Presets.cs
         * 
         * Responsbilities:
         * 1) Raising Room Volume
         * 2) Lowering Room Volume
         * 3) Muting and Unmuting Room Volume
         * 4) Recalling Volume Presets
         * 5) Reporting whether the Room Volume Matches one of the Presets
         * 
         * Additional Notes:
         * 
         * 
         * 
         */
        ushort previousVolume;                                                                  //Storing of Previous Volume level for Mute Toggling                        
        uint rampTime;                                                                          //Ramp Time for Raising and Lowering Volume
        ushort minValue;                                                                        //Maximum Volume Level
        ushort maxValue;                                                                        //Minimum Volume Level
        ushort finalRampValue;                                                                  //This variable is used for setting the final value the volume ramp will go to when a Preset is recalled. This is used for scenarios in which the Preset may have been set to above or below the min or max value
        ushort increment;                                                                       //The amount the volume will increment by
        int repeatTime;                                                                         //How often the volume will be incremeneted after, 
        int holdTime;                                                                           //the initial holdTime is met
        bool raise;                                                                             //Flag for identifying whether the volume is being raised - true = raising, false = lowering / not in use

        PresetCheckerEventArgs presetCheckerEventArgs;                                          //This is used for setting the Arguments to be raised by the PresetCheckerEvent
        Thread presetEvaluator;                                                                 //Thread used for constantly checking if the Room Volume matches one of the Volume Presets
        CTimer rampVolumeTimer;                                                                 //Timer used for triggering the VolumeRampCallback CallbackFunction, this is what controls how often the volume is incremented
        UShortInputSig volumeRampingInputSignal;                                                //The Signal which will be used for ramping the Volume of the room
        UShortOutputSig volumeRampingFeedbackSignal;                                            

        /* Volume Controls Constructor
         * When the class is instantiated, do the following:
         *      - Set the Ushort value which will be used to control the volume
         *      - Instantiate the PresetCheckerEventArgs, to pass back information in regards to which preset is active
         *      - Set the previousVolume ushort to the current volume of the RMC-4K-SCALER-C > This will be used for Mute Toggling
         *      - Set the rampTime ushort to the the RampTime parameter
         *      - Instantiate the new Thread, and start the thread (Thread.eThreadStartOptions.Running)
         *      - Set the Thread priority to Lowest priority
         *      - Set the Minimum and Maximum volume levels
         *      - Set the incremenet value, Hold Times and repeatTime for the rampVolumeTimer and the VolumeRampCallback CallbackFunction
         *      - Set the Raise flag to false
         *      - Instantiate the CTimer and Stop the timer for firing.
         */

        public VolumeControls(UShortInputSig ValueToControl, UShortOutputSig ValueFeedback,uint RampTime, ushort MinValue, ushort MaxValue, ushort IncrementValue, int RepeatTimeinMs, int HoldTime)
        {
            volumeRampingInputSignal = ValueToControl;
            volumeRampingFeedbackSignal = ValueFeedback;                                                
            presetCheckerEventArgs = new PresetCheckerEventArgs();                                                  
            previousVolume = volumeRampingInputSignal.UShortValue;                                                  
            rampTime = RampTime;                                                                                    
            presetEvaluator = new Thread(PresetChecker, null, Thread.eThreadStartOptions.Running);                  
            presetEvaluator.Priority = Thread.eThreadPriority.LowestPriority;                                       
            minValue = MinValue;                                                                                    
            maxValue = MaxValue;                                                                                    
            increment = IncrementValue;
            holdTime = HoldTime;
            raise = false;                                                                                          
            repeatTime = RepeatTimeinMs;                                                                                                                                                 
            rampVolumeTimer = new CTimer(VolumeRampCallback, null, repeatTime);                                     
            rampVolumeTimer.Stop();                                                                                 
        }

        /* Add Preset Method
         * Used for adding a Preset to the PresetList for future recalling purposes
         */
 
        public void AddPreset(ushort PresetValue, uint RampTime)
        {
            if (PresetValue > maxValue)
            {
                AddToPresetList(maxValue, RampTime);
            }
            else if (PresetValue < minValue)
            {
                AddToPresetList(minValue, RampTime);
            }
            else
            {
                AddToPresetList(PresetValue, RampTime);
            }
        }

        /* Raise Volume Method
         * Creates a ramp to raise the volume of DM-RMC-4K-SCALER-C         
         */
        public void RaiseVolume()
        {
            raise = true;
            VolumeRampCallback(null);
            rampVolumeTimer.Reset(holdTime, repeatTime);
        }

        /* Lower Volume Method
         * Creates a ramp to lower the volume of DM-RMC-4K-SCALER-C
         */
        public void LowerVolume()
        {
            raise = false;
            VolumeRampCallback(null);
            rampVolumeTimer.Reset(holdTime, repeatTime);
        }

        /* Cancel Ramp Method
         * Stops the Ramp Created by either the Raise of Lower Methods
         */
        public void CancelRamp()
        {
            rampVolumeTimer.Stop();
            raise = false;
        }

        /* Mute Toggle Method
         * Toggling the Volume between 0% and previousValue
         */
        public bool MuteToggle()
        {
            if (volumeRampingInputSignal.UShortValue == 0)
            {
                volumeRampingInputSignal.UShortValue = previousVolume;
                return false;
            }
            else
            {
                previousVolume = volumeRampingInputSignal.UShortValue;
                volumeRampingInputSignal.UShortValue = 0;
                return true;
            }
        }

        /* Abort Thread Method
         * Used to Abort the Preset Evaluate Thread        
         */
        public void AbortThread()
        {
            try
            {
                presetEvaluator.Abort();
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error aborting Preset Evaluate Thread, Reason: {0}", e.Message);
            }
        }

        /* Preset Recall Method
         * this is used for Recalling a Preset
         */
        public override void RecalPreset(int Index)
        {
            KeyValuePair<ushort, uint> presetToRecall = GetPresetValues(Index);
            try
            {
                if (presetToRecall.Value != 0)
                {
                    if (presetToRecall.Key > maxValue)
                    {
                        finalRampValue = maxValue;
                    }
                    else if (presetToRecall.Key < minValue)
                    {
                        finalRampValue = minValue;
                    }
                    else
                    {
                        finalRampValue = presetToRecall.Key;
                    }
                    rampTime = presetToRecall.Value;

                    volumeRampingInputSignal.CreateRamp(finalRampValue, rampTime);
                }
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error Recalling Preset, Reason {0}", e.Message);
            }
        }

        /* Preset Checker Method 
         * this is used for constantly checking the volume level of the UshortInputSignal 
         * and raising the PresetCheckerEvent when one of the two scenarios are met:
         *  1) One of the Volume Presets is matched with the currentl volume level of UshortInputSignal
         *  2) When a match no longer exists after, a match to a Volume Preset was found
         *  
         * This Event is then used in the ControlSystem.cs to set feedback for the appropriate Volume Preset
         */
        public object PresetChecker(object o)
        {
            bool presetMatch = false;                                                                       //When this ThreadCallbackFunction is called, reset the presetMatch and update Flags
            bool update = false;
            while (true)                                                                                    //A while loop is used to ensure that this thread is always running. Note! Previously the Thread Priority was set to Lowest
            {
                if (!presetMatch)                                                                           //If a Preset has not been matched, look for a matching preset
                {
                    foreach (KeyValuePair<ushort, uint> preset in PresetList)                               //Check each Preset in our PresetList
                    {
                        if (volumeRampingFeedbackSignal.UShortValue == preset.Key && presetMatch == false)     //if the Volume Feedback is equal to the preset, and a Preset Has not been Matched yet
                        {
                            presetCheckerEventArgs.PresetIndex = PresetList.IndexOf(preset) + 1;            //Set the Event Args for the Event that is about to be raised
                            presetCheckerEventArgs.MatchState = true;                                   
                            presetMatch = true;                                                             //Set the presetMatch flag to High (true)
                            update = true;                                                                  //Set the update flag to High(true) so that the Event can be raised
                        }
                    }
                }

                if (presetMatch == true)                                                                                                    // If a preset has been matched                                                                                              
                {
                    if (PresetList[presetCheckerEventArgs.PresetIndex - 1].Key != volumeRampingFeedbackSignal.UShortValue)                     //Verify whether the Match is still valid, if it is not
                    {
                        presetCheckerEventArgs.PresetIndex = 0;                                                                             //Set the Event Args for the Event that is about to be raised
                        presetCheckerEventArgs.MatchState = false;
                        update = true;                                                                                                      //Set the update flag to High(true) so that the Event can be raised
                        presetMatch = false;                                                                                                //Set the presetMatch flag to Low (false)
                    }
                }

                Thread.Sleep(5);                                                                                                                //Pause the Thread for 5ms

                if (update)                                                                                                                     //Check the update Flag, if it is High
                {
                    Thread.Sleep(10);                                                                                                           
                    if (PresetCheckerEvent != null)                                                                                             //Check that there is a subscriber to the PresetCheckerEvent
                    {
                        PresetCheckerEvent(this, presetCheckerEventArgs);                                                                       //If so, raise the event
                        update = false;                                                                                                         //And set the update Flag to Low
                    }
                }

                Thread.Sleep(50);                                                                                                               //Pause the Thread for 50ms, this defines that the Volume will be checked approximately every 50ms
            }

        }

        /* Volume Ramping Callback Method
         * Method called, when rampVolumeTimer CTimer expires.
         * This Method is in charge of controlling the increment of volume in the room.
         * It also checks to make sure that the minimum and maximum value are not passed.
         */
        public void VolumeRampCallback(object o)
        {
            try
            {
                if (raise)
                {
                    if ((volumeRampingInputSignal.UShortValue += increment) > maxValue)
                    {
                        volumeRampingInputSignal.UShortValue = maxValue;
                    }
                    else
                    {
                        volumeRampingInputSignal.UShortValue += increment;
                    }
                }
                else if (!raise)
                {
                    if ((volumeRampingInputSignal.UShortValue -= increment) < minValue)
                    {
                        volumeRampingInputSignal.UShortValue = minValue;
                    }
                    else
                    {
                        volumeRampingInputSignal.UShortValue -= increment;
                    }
                }
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error Ramping Volume, Reason: {0}", e.Message);
            }            
        }

        /* Preset Checker Event
         * Event for informing program, which Preset is currently active
         */
        public event EventHandler<PresetCheckerEventArgs> PresetCheckerEvent;
    }

    /* Preset Checker Event Args
     * Event Arguments for PresetChecker Event, this is used for sending back, which Preset is active
     */
    public class PresetCheckerEventArgs : EventArgs
    {
        internal int PresetIndex;
        internal bool MatchState;
    }

}