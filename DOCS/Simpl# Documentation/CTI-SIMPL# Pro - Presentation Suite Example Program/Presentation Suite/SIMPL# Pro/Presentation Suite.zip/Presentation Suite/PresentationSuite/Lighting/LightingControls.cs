﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharpPro;
using Crestron.SimplSharpPro.Lighting.Din;
using Crestron.SimplSharpPro.CrestronThread;

namespace PresentationSuite
{
    public class LightingPresets : Preset
    {

        /* Lighting Presets
         * Info
         * > Lighting Presets inherits Presets.cs, found under Functionality\Presets.cs
         */

        #region Fields
        List<DinFluorescentBallasts> loadsToDim;                                            //List of Loads for Lighting Preset Class to Control
        SigGroup valueToUpdate;                                                             //Sig Group to update Touch Panel Gauge 
        Thread presetRecall;                                                                //Thread using for Recalling Presets
        ushort maxValue;                                                                    //Used for storing the maximum value
        uint rampTime;                                                                      //Used for storing the ramp time
        #endregion

        /* Lighting Presets Method
         * Constructor for LightingPresets class, which performs the following:
         *      - Sets the loadsToDimList
         *      - sets the maxValue
         *      - Sets the rampTime
         *      - sets the valueToUpdate SigGroup
         */
        public LightingPresets(List<DinFluorescentBallasts> LoadsToDim, SigGroup ValuesToUpdate)
        {
            try
            {
                loadsToDim = LoadsToDim;
                maxValue = 0;
                rampTime = 0;
                valueToUpdate = ValuesToUpdate;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error adding Preset to Control System, Reason: {0}", e.Message);
            }
        }

        /* Abort Thread Method
         * Used for Aborting the presetRecall Thread
         */
        public void AbortThread()
        {
            try
            {
                presetRecall.Abort();
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error abprting Preset Recall Thread, Reason: {0}", e.Message);
            }
        }

        /* Recall Preset Method
         * This is a method included in the inherited Preset Class. It can be overriden, based upon the requirements for this class
         * The Signature must match the RecalPreset Method in the Preset Class.
         */
        public override void RecalPreset(int Index)
        {
            KeyValuePair<ushort, uint> presetToRecall = GetPresetValues(Index);
            try
            {
                if (presetToRecall.Value != 0)                                                              //Check that the ramp Time is not equal to 0
                {
                    maxValue = presetToRecall.Key;                                                          //Set the maxValue to the Key of KeyValuePair
                    rampTime = presetToRecall.Value;                                                        //Set the rampTime to the Value of KeyValuePair

                    foreach (var load in loadsToDim)
                    {
                        presetRecall = new Thread(RunPreset, load, Thread.eThreadStartOptions.Running);     //Foreach Load, create a thread to recall the preset
                    }
                    valueToUpdate.CreateRamp(maxValue, rampTime);                                           //Create a Ramp for the gauge on the Touch Panel
                }
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error Recalling Preset, Reason {0}", e.Message);
            }
        }

        /* Add Preset Method
         * Method to add a Preset to Preset List
         */ 
        public void AddPreset(ushort PresetVaue, uint RampTime)
        {
            try
            {
                AddToPresetList(PresetVaue, RampTime);
            }
            catch (Exception e)
            {
                ErrorLog.Notice("Error Adding a Preset, Reason: {0}", e.Message);
            }
        }

        /* Run Preset Method
         * Thread that is run, for Recalling a Preset
         */
        public object RunPreset(object o)
        {
            DinFluorescentBallasts tempLoad = (DinFluorescentBallasts)o;                    //The passed in parameter is "o", is explicitly cast as a DinFluorescentBallasts, so it can be controllled
            tempLoad.LevelIn.CreateRamp(maxValue, rampTime);                                //Create a ramp for the load
            return o;                                                                       //The signature of the ThreadCallbackFunction, requires that an object is returned
        }

    }
}