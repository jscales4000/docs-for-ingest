﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharpPro.Keypads;
using Crestron.SimplSharpPro.Lighting;

namespace PresentationSuite
{
    public static class KeypadFunctions
    {
        /*  Static Class (does not need to instantiated) for setting the feedback on the appropriate button
        *   The button number and keypad are passed into the static class.
        *   The class then iterrates through all the buttons in the Keypad, and sets only the pressed Button
        */ 
        public static void SetKeypadFeedback(uint Button, ref C2nCbdP Keypad)
        {
            try
            {
                foreach (var btn in Keypad.Button)
                {
                    if (btn.Number <= Keypad.Feedbacks.Count)
                    {
                        if (btn.Number == Button)
                        {
                            Keypad.Feedbacks[btn.Number].State = true;
                        }
                        else
                        {
                            Keypad.Feedbacks[btn.Number].State = false;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error setting keypad feedback, Reason: {0}", e.Message);
            }
        }
    }
}